package com.vidgrab.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.vidgrab.app.MainActivity
import com.vidgrab.app.R
import com.vidgrab.app.core.DlStatus
import com.vidgrab.app.core.DownloadRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Foreground download engine — app swipe/close hone par bhi downloads chalte rahenge.
 * START_STICKY: process mar bhi jaye to system restart karta hai, queue persist se resume.
 */
class DownloadService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var wakeLock: PowerManager.WakeLock? = null
    private val workerStarted = AtomicBoolean(false)
    private var lastNotifUpdate = 0L

    override fun onCreate() {
        super.onCreate()
        createChannel(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        // START_STICKY restart (intent == null) par bhi worker wapas chalu
        ensureWorker()
        return START_STICKY
    }

    private fun ensureWorker() {
        if (!workerStarted.compareAndSet(false, true)) return
        scope.launch {
            // Notif progress updater
            launch {
                while (true) {
                    delay(700)
                    updateProgressNotification()
                }
            }
            // Queue consumer
            for (item in DownloadRepository.queue) {
                acquireWakeLock()
                try {
                    DownloadRepository.executeOne(item)
                } catch (_: Exception) {
                } finally {
                    releaseWakeLock()
                }
            }
        }
    }

    private fun startAsForeground() {
        val notif = buildNotification(getString(R.string.notif_downloading), "Starting download…", 0f, false)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun buildNotification(title: String, text: String, progress: Float, indeterminate: Boolean): Notification {
        val contentIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(contentIntent)
            .setProgress(100, progress.toInt(), indeterminate)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    private fun updateProgressNotification() {
        val now = System.currentTimeMillis()
        if (now - lastNotifUpdate < 500) return
        lastNotifUpdate = now
        val current = DownloadRepository.active.value.firstOrNull {
            it.status == DlStatus.DOWNLOADING || it.status == DlStatus.MERGING ||
                it.status == DlStatus.FETCHING || it.status == DlStatus.QUEUED
        } ?: return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        // Processing phase (queue wait / extraction) vs actual download — dono ka alag title
        val preparing = current.status == DlStatus.QUEUED || current.status == DlStatus.FETCHING
        // v2.2.1: MERGING par bhi indeterminate bar — merge/safe save mein bhi progress dikhta rahe
        val indeterminate = preparing || current.status == DlStatus.MERGING
        val title = getString(if (preparing) R.string.notif_preparing else R.string.notif_downloading)
        val text = when (current.status) {
            DlStatus.MERGING -> "Finalizing ${current.title.take(28)}"
            DlStatus.QUEUED, DlStatus.FETCHING -> "Processing ${current.title.take(28)}…"
            else -> {
                val speed = UrlUtilsKt.speedText(current.speedBps)
                "${current.title.take(24)} • ${current.progress.toInt()}%$speed"
            }
        }
        nm.notify(NOTIF_ID, buildNotification(title, text, current.progress, indeterminate))
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        wakeLock = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VidGrab:download")
        wakeLock?.acquire(6 * 60 * 60 * 1000L)
    }

    private fun releaseWakeLock() {
        try { wakeLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) { }
    }

    override fun onTimeout(startId: Int, fgsType: Int) {
        // Android 15+ dataSync 6h limit — gracefully stop
        stopSelf()
    }

    override fun onDestroy() {
        releaseWakeLock()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_ID = "vidgrab_downloads"
        const val NOTIF_ID = 101

        fun createChannel(ctx: Context) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(
                CHANNEL_ID, ctx.getString(R.string.notif_channel_downloads),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = ctx.getString(R.string.notif_channel_downloads_desc)
                setShowBadge(false)
            }
            nm.createNotificationChannel(ch)
        }

        @Volatile
        var isRunning = false
            private set

        fun start(ctx: Context) {
            val i = Intent(ctx, DownloadService::class.java)
            try {
                ctx.startForegroundService(i)
            } catch (_: Exception) { }
        }
    }
}

/** Chhota helper — UrlUtils import circular na ho isliye yahan */
object UrlUtilsKt {
    fun speedText(bps: Long): String =
        if (bps <= 0) "" else {
            val mb = bps / (1024.0 * 1024.0)
            val kb = bps / 1024.0
            " • " + if (mb >= 1) String.format(java.util.Locale.US, "%.1f MB/s", mb)
            else String.format(java.util.Locale.US, "%.0f KB/s", kb)
        }
}
