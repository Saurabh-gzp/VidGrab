package com.vidgrab.app.util

import android.content.Context
import com.vidgrab.app.core.FormatOption
import com.vidgrab.app.core.VideoMeta
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Locale

/**
 * Extraction wrapper:
 *  - POORA quality ladder (Best se lekar 8K tak jo bhi available ho)
 *  - Sahi size estimate (video + audio ka SUM, approx ka sahi use)
 *  - Extraction client fallback chain (jab ek route block ho)
 */
object Fetcher {

    data class FetchResult(val meta: VideoMeta, val formats: List<FormatOption>)

    /** Extraction routes — pehla jo chale wahi final (download bhi usi se) */
    private val CLIENT_FALLBACKS = listOf<String?>(
        null,
        "youtube:player_client=android_vr",
        "youtube:player_client=ios",
        "youtube:player_client=tv_embedded",
        "youtube:player_client=web_embedded"
    )

    private val BOT_HINTS = listOf(
        "sign in to confirm", "confirm you're not a bot", "not a bot",
        "unable to extract", "player response", "login required",
        "requested content is not available", "age-restricted"
    )

    suspend fun fetchInfo(appCtx: Context, rawUrl: String): FetchResult = withContext(Dispatchers.IO) {
        val url = UrlUtils.normalize(rawUrl)
        var lastErr: Exception? = null
        for (clientArgs in CLIENT_FALLBACKS) {
            try {
                val json = dumpJson(appCtx, url, clientArgs)
                val result = parseMeta(url, json, clientArgs)
                return@withContext result
            } catch (e: Exception) {
                lastErr = e
                val msg = (e.message ?: "").lowercase(Locale.ROOT)
                // Block-type error par hi agla route try karo; 404 jaise errors par turant ruko
                val retryable = BOT_HINTS.any { it in msg } || msg.contains("player") || msg.contains("fetch")
                if (!retryable && msg.contains("does not exist")) throw e
            }
        }
        throw lastErr ?: Exception("Could not fetch video info")
    }

    fun dumpJson(appCtx: Context, url: String, clientArgs: String?): JSONObject {
        val req = YoutubeDLRequest(url)
        req.addOption("--dump-single-json")
        req.addOption("--no-playlist")
        req.addOption("--no-warnings")
        req.addOption("--socket-timeout", "20")
        req.addOption("--retries", "3")
        if (clientArgs != null) req.addOption("--extractor-args", clientArgs)
        val resp = YoutubeDL.getInstance().execute(req, null, null)
        if (resp.exitCode != 0) {
            val err = resp.err?.takeIf { it.isNotBlank() } ?: resp.out
            throw Exception(err.takeLast(400).ifBlank { "Extraction failed (code ${resp.exitCode})" })
        }
        val out = resp.out.trim()
        val start = out.indexOf('{')
        if (start < 0) throw Exception("Empty response from extractor")
        return JSONObject(out.substring(start))
    }

    private fun parseMeta(url: String, json: JSONObject, clientArgs: String?): FetchResult {
        val meta = VideoMeta(
            id = json.optString("id", ""),
            title = json.optString("title", "Video"),
            uploader = json.optString("uploader", json.optString("channel", "")).ifBlank { null },
            durationSec = if (json.has("duration")) json.optDouble("duration").toLong() else null,
            thumbnailUrl = json.optString("thumbnail", "").ifBlank { null },
            webpageUrl = json.optString("webpage_url", url),
            platform = UrlUtils.platformOf(url),
            extractor = json.optString("extractor_key", "").ifBlank { null },
            clientArgs = clientArgs
        )
        val formats = buildFormats(json, meta)
        return FetchResult(meta, formats)
    }

    fun buildFormats(json: JSONObject, meta: VideoMeta): List<FormatOption> {
        val duration = meta.durationSec ?: 0L
        val arr = json.optJSONArray("formats")
        val formats = mutableListOf<FormatOption>()

        data class VF(
            val height: Int, val width: Int?, val tbr: Double, val size: Long?,
            val isApprox: Boolean, val muxed: Boolean, val https: Boolean,
            val fps: Double?, val ext: String
        )

        val videos = mutableListOf<VF>()
        val audios = mutableListOf<Pair<Double, Long?>>() // abr/tbr to size

        if (arr != null) {
            for (i in 0 until arr.length()) {
                val f = arr.optJSONObject(i) ?: continue
                val vcodec = f.optString("vcodec", "none")
                val acodec = f.optString("acodec", "none")
                val tbr = f.optDouble("tbr", 0.0)
                val filesize = f.optLong("filesize", -1L).takeIf { it > 0 }
                    ?: f.optLong("filesize_approx", -1L).takeIf { it > 0 }
                val isApproxSize = f.optLong("filesize", -1L) <= 0 && f.optLong("filesize_approx", -1L) > 0
                val protocol = f.optString("protocol", "https")
                when {
                    vcodec != "none" && f.has("height") -> {
                        val h = f.optInt("height", 0)
                        if (h > 0) {
                            // HLS/DASH bhi allowed — sirf prefer kam (https ko priority milti hai)
                            videos += VF(
                                height = h,
                                width = f.optInt("width", 0).takeIf { it > 0 },
                                tbr = tbr,
                                size = filesize,
                                isApprox = isApproxSize,
                                muxed = acodec != "none",
                                https = protocol.startsWith("https") || protocol.startsWith("http"),
                                fps = f.optDouble("fps", 0.0).takeIf { it > 0.0 },
                                ext = f.optString("ext", "mp4")
                            )
                        }
                    }
                    vcodec == "none" && acodec != "none" -> {
                        audios += (f.optDouble("abr", 0.0).takeIf { it > 0 } ?: tbr) to filesize
                    }
                }
            }
        }

        // Best audio size (merge estimate ke liye)
        val bestAudioSize: Long? = audios.maxByOrNull { it.first }
            ?.second
            ?: audios.maxOfOrNull { it.second ?: 0L }?.takeIf { it > 0 }

        videos.sortWith(compareByDescending<VF> { it.height }.thenByDescending { it.tbr })

        // Har height ka BEST variant (https prefer, phir tbr)
        val byHeight = videos.groupBy { it.height }
        val qualityList = mutableListOf<FormatOption>()

        for ((height, group) in byHeight.toSortedMap(compareByDescending { it })) {
            val best = group.sortedWith(
                compareByDescending<VF> { it.https }.thenByDescending { it.tbr }
            ).first()
            val vBytes = best.size ?: (if (best.tbr > 0 && duration > 0) (best.tbr * 1000 / 8.0 * duration).toLong() else null)
            val total = when {
                vBytes == null -> null
                best.muxed -> vBytes
                else -> vBytes + (bestAudioSize ?: 0L)
            }
            val isApprox = best.isApprox || best.size == null
            val dim = if (best.width != null) "${best.width}×$height" else "${height}p"
            val fpsTag = best.fps?.let { " • ${it.toInt()}fps" } ?: ""
            val qTag = UrlUtils.qualityLabel(height)
            val label = if (qTag.endsWith("p") || qTag.endsWith("K") || qTag.endsWith("HD")) {
                if (qTag == "${height}p") "${height}p" else "$qTag ${height}p"
            } else "$qTag ${height}p"
            qualityList += FormatOption(
                id = "h$height",
                label = label,
                detail = "$dim$fpsTag • ${UrlUtils.formatBytes(total)}${if (isApprox && total != null) " approx" else ""}",
                // v2.2.1 MERGE-SAFETY: ≤1080p par YouTube ke AVC1 (mp4) video + M4A audio
            // prefer karo — h264+aac ka mp4 stream-copy merge har ffmpeg build par
            // bulletproof hai. VP9/AV1 (webm) merge kuch devices par atak/fail hota
            // tha. Fallback chain mein best available streams hamesha hain.
            selector = if (best.muxed) {
                "best[height<=$height]/bestvideo[height<=$height]+bestaudio/best"
            } else if (height <= 1080) {
                "bv*[vcodec^=avc1][height<=$height]+ba[acodec^=mp4a]/" +
                    "bestvideo[height<=$height]+bestaudio/" +
                    "best[height<=$height]/best"
            } else {
                "bestvideo[height<=$height]+bestaudio/best[height<=$height]/best"
            },
                estBytes = total,
                isApprox = isApprox,
                isAudioOnly = false,
                height = height
            )
        }

        // Sabse top: absolute best (no cap)
        val maxHeight = videos.maxOfOrNull { it.height }
        val bestLabel = maxHeight?.let { h ->
            val q = UrlUtils.qualityLabel(h)
            if (q.endsWith("p")) q else "$q (${h}p)"
        } ?: "Best quality"
        val bestTotal = qualityList.firstOrNull()?.estBytes
        formats += FormatOption(
            id = "best",
            label = "Best — $bestLabel",
            detail = "Highest available • ${UrlUtils.formatBytes(bestTotal)}",
            // v2.2.1: Best bhi pehle AVC1+M4A try kare (≤1080p par mil jata hai);
            // >1080p (4K etc.) par AVC1 nahi hota — khud bestvideo* (VP9/AV1) chalega
            selector = "bv*[vcodec^=avc1]+ba[acodec^=mp4a]/bestvideo*+bestaudio/best/bestvideo+bestaudio",
            estBytes = bestTotal,
            isApprox = qualityList.firstOrNull()?.isApprox ?: true,
            isAudioOnly = false,
            height = maxHeight
        )
        formats += qualityList

        // Audio options
        val m4aSize = bestAudioSize
        formats += FormatOption(
            id = "m4a",
            label = "Audio — M4A",
            detail = "Original audio quality • ${UrlUtils.formatBytes(m4aSize)}",
            selector = "bestaudio[ext=m4a]/bestaudio/best",
            estBytes = m4aSize,
            isApprox = true,
            isAudioOnly = true
        )
        formats += FormatOption(
            id = "mp3",
            label = "Audio — MP3",
            detail = "Converted, best bitrate • ${if (m4aSize != null) "~" else ""}${UrlUtils.formatBytes(m4aSize)}",
            selector = "bestaudio/best",
            estBytes = m4aSize,
            isApprox = true,
            isAudioOnly = true,
            postArgs = listOf("--extract-audio", "--audio-format", "mp3", "--audio-quality", "0")
        )
        return formats
    }
}
