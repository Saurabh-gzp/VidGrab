package com.vidgrab.app.core

import android.content.Context
import android.util.Log
import com.vidgrab.app.service.DownloadService
import com.vidgrab.app.util.MediaSaver
import com.vidgrab.app.util.UrlUtils
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Download brain:
 *  - Queue channel — DownloadService worker consume karta hai
 *  - Sab state StateFlow se — UI instantly refresh
 *  - Active queue persist — process kill/restart par resume
 *
 * v2.2.1 ROBUSTNESS (user feedback: "2 baar download + Finalizing stuck"):
 *  - Inactivity watchdog — 10 min tak koi progress line nahi → process kill → salvage
 *  - Salvage merge — yt-dlp ka merge fail/skip ho to AAPKA khud ka ffmpeg
 *    (libffmpeg.so) video+audio parts ko merge karta hai
 *  - No blind retry — download ke baad ka failure (merge etc.) kabhi poora
 *    download dobara NAHI karta; pehle already-downloaded file salvage karo
 *  - Cancel vs watchdog clearly flagged (message-string matching hataya)
 */
object DownloadRepository {

    private const val TAG = "DownloadRepo"

    /** Itni der tak ek bhi progress line nahi → process ko kill karke salvage karo */
    private const val INACTIVITY_TIMEOUT_MS = 10 * 60 * 1000L

    /** Apne ffmpeg salvage merge ka hard timeout */
    private const val SALVAGE_TIMEOUT_MS = 10 * 60 * 1000L

    /** yt-dlp part files: "Title [id].f137.mp4" style */
    private val PART_RX = Regex("""^(.+)\.f\d+\.[A-Za-z0-9]+$""")

    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _active = MutableStateFlow<List<DownloadItem>>(emptyList())
    val active: StateFlow<List<DownloadItem>> = _active

    private val _history = MutableStateFlow<List<HistoryEntry>>(emptyList())
    val history: StateFlow<List<HistoryEntry>> = _history

    internal val queue = Channel<DownloadItem>(Channel.UNLIMITED)

    private lateinit var appCtx: Context
    private val initialized = AtomicBoolean(false)
    private var persistJob: kotlinx.coroutines.Job? = null

    /** Monotonic seq — same millisecond mein bhi id kabhi collide nahi kar sakta */
    private val idSeq = AtomicLong(0)

    // ----- v2.2.1 per-item runtime state -----
    private val lastActivityMs = ConcurrentHashMap<String, Long>()
    private val watchdogFired = ConcurrentHashMap<String, Boolean>()
    private val userCancelled = ConcurrentHashMap<String, Boolean>()

    fun initOnce(ctx: Context) {
        if (initialized.compareAndSet(false, true)) {
            appCtx = ctx.applicationContext
            // DataStore load main-thread block na kare — background mein
            appScope.launch {
                val stored = Prefs.loadDownloads(appCtx)
                // Data hygiene — purane builds se duplicate ids aaye to bhi safe rahe
                _history.value = stored.history.distinctBy { it.id }
                // Crash/restart se bache hue in-flight items wapas queue mein (resume)
                // NOTE: yt-dlp resume-by-default hai — .part files wapas uthal leta hai,
                // poora re-download sirf tab hota hai jab file adhoora ho.
                val resumable = stored.active
                    .distinctBy { it.id }
                    .filter {
                        it.status == DlStatus.QUEUED || it.status == DlStatus.DOWNLOADING ||
                            it.status == DlStatus.FETCHING || it.status == DlStatus.MERGING
                    }
                if (resumable.isNotEmpty()) {
                    _active.value = resumable.map { it.copy(status = DlStatus.QUEUED, progress = 0f, error = null) }
                    _active.value.forEach {
                        if (it.status == DlStatus.QUEUED) queue.send(it)
                    }
                } else {
                    _active.value = stored.active
                }
                File(appCtx.filesDir, "downloads").mkdirs()
            }
        }
    }

    /** UI se entry point — service start + queue */
    fun enqueue(
        url: String,
        meta: VideoMeta,
        format: FormatOption
    ) {
        val item = DownloadItem(
            // CRASH FIX: seq counter ke sath id — do items ka key kabhi same nahi
            id = "dl_${System.currentTimeMillis()}_${idSeq.incrementAndGet()}",
            url = meta.webpageUrl.ifBlank { url },
            title = meta.title,
            thumbnailUrl = meta.thumbnailUrl,
            status = DlStatus.QUEUED,
            formatLabel = format.label,
            selector = format.selector,
            postArgs = format.postArgs,
            clientArgs = meta.clientArgs,
            totalBytes = format.estBytes ?: 0L,
            mimeHint = if (format.isAudioOnly) "audio" else "video",
            height = format.height
        )
        _active.value = _active.value + item
        persist()
        try {
            DownloadService.start(appCtx)
        } catch (_: Exception) { }
        appScope.launch { queue.send(item) }
    }

    fun cancel(id: String) {
        appScope.launch {
            userCancelled[id] = true
            try { YoutubeDL.getInstance().destroyProcessById(id) } catch (_: Exception) { }
            patch(id) { it.copy(status = DlStatus.CANCELLED) }
            delay(600)
            _active.value = _active.value.filterNot { it.id == id }
            persist()
        }
    }

    /** Active failed/queued item hatao (swipe-dismiss style) */
    fun dismiss(id: String) {
        _active.value = _active.value.filterNot { it.id == id }
        persist()
    }

    /** History se delete — file + MediaStore entry + instant UI refresh */
    fun deleteHistory(entry: HistoryEntry) {
        appScope.launch {
            try { MediaSaver.deleteByPath(appCtx, entry.filePath) } catch (_: Exception) { }
            _history.value = _history.value.filterNot { it.id == entry.id }
            persist()
        }
    }

    fun clearHistory() {
        _history.value = emptyList()
        persist()
    }

    // ------------- worker (DownloadService se chalaya jata hai) -------------

    suspend fun executeOne(item: DownloadItem) {
        watchdogFired.remove(item.id)
        userCancelled.remove(item.id)
        executeWithRetry(item, attempt = 1)
    }

    private suspend fun executeWithRetry(item: DownloadItem, attempt: Int) {
        // Engine update chal raha ho to ruk jao (binary swap corrupt na ho)
        var waited = 0L
        while (UpdateManager.isUpdating() && waited < 10 * 60 * 1000L) {
            delay(1000); waited += 1000
        }
        if (!Engine.await()) {
            fail(item, UrlUtils.friendlyEngineError(Engine.lastError ?: "Engine not ready"))
            return
        }
        patch(item.id) { it.copy(status = DlStatus.FETCHING, progress = 0f) }
        lastActivityMs[item.id] = System.currentTimeMillis()

        val dir = File(appCtx.filesDir, "downloads").apply { mkdirs() }
        // SNAPSHOT: download se pehle jo files already thi — output dhoondne ke liye
        val before = dir.listFiles()?.map { it.absolutePath }?.toSet() ?: emptySet()

        val req = YoutubeDLRequest(item.url)
        req.addOption("-o", File(dir, "%(title).70s [%(id)s].%(ext)s").absolutePath)
        req.addOption("-f", item.selector)
        req.addOption("--no-playlist")
        req.addOption("--no-warnings")
        req.addOption("--no-mtime")
        req.addOption("--newline")
        req.addOption("--retries", "5")
        req.addOption("--fragment-retries", "10")
        req.addOption("--socket-timeout", "20")
        req.addOption("--concurrent-fragments", "4")
        if (item.mimeHint == "video") req.addOption("--merge-output-format", "mp4")
        // RETRY attempt par extractor-args hata do — fresh default client se try
        val useClientArgs = if (attempt > 1) null else item.clientArgs
        if (useClientArgs != null) req.addOption("--extractor-args", useClientArgs)
        // postArgs ko flag/value pairs mein todo
        var ai = 0
        val pa = item.postArgs
        while (ai < pa.size) {
            val a = pa[ai]
            if (a.startsWith("--") && ai + 1 < pa.size && !pa[ai + 1].startsWith("--")) {
                req.addOption(a, pa[ai + 1]); ai += 2
            } else {
                req.addOption(a); ai += 1
            }
        }

        val watchdog = startWatchdog(item.id)
        try {
            val resp = withContext(Dispatchers.IO) {
                YoutubeDL.getInstance().execute(req, item.id) { progress: Float, etaSec: Long, line: String? ->
                    onUpdateLine(item.id, progress, etaSec, line ?: "")
                }
            }
            watchdog.cancel()

            if (resp.exitCode != 0) {
                // v2.2.1 FIX: exit-code!=0 par ANDHA retry NAHI — pehle dekho file
                // download hui hai (merge fail hua hoga). Mile to finalize karo,
                // poora re-download user ko kabhi na dikhe.
                val salvaged = salvageDeliverable(dir, item, before)
                if (salvaged != null) {
                    Log.w(TAG, "exit=${resp.exitCode} par deliverable mila — salvage finalize")
                    finalizeItem(item, salvaged)
                } else {
                    val err = resp.err?.takeIf { it.isNotBlank() } ?: resp.out ?: ""
                    handleFailure(item, err, attempt)
                }
                return
            }

            var file = findOutput(dir, item, before)
            if (file == null) {
                // yt-dlp "succeed" hai par merged file nahi — parts alag pade hain
                file = salvageMerge(item, dir)
            }
            if (file == null) {
                handleFailure(item, "Output file not found after download", attempt)
                return
            }
            finalizeItem(item, file)
        } catch (e: Exception) {
            watchdog.cancel()
            when {
                userCancelled[item.id] == true -> {
                    _active.value = _active.value.filterNot { it.id == item.id }
                    persist()
                }
                // v2.2.1 FIX: library "Canceled" (one-L) message bhi bhej sakti hai —
                // string matching pe bharosa nahi, flags use karte hain
                watchdogFired[item.id] == true -> {
                    val salvaged = salvageDeliverable(dir, item, before)
                    if (salvaged != null) {
                        Log.w(TAG, "watchdog fired — salvaged deliverable, finalizing")
                        finalizeItem(item, salvaged)
                    } else {
                        fail(item, "Download stalled too long — please try again")
                    }
                }
                else -> {
                    val msg = e.message ?: ""
                    if (msg.contains("cancel", true) || msg.contains("interrupt", true)) {
                        _active.value = _active.value.filterNot { it.id == item.id }
                        persist()
                    } else {
                        Log.e(TAG, "download failed: $msg")
                        handleFailure(item, msg, attempt)
                    }
                }
            }
        } finally {
            watchdog.cancel()
            lastActivityMs.remove(item.id)
            watchdogFired.remove(item.id)
        }
    }

    /** Success path ka last mile — rename + save + history + cleanup */
    private suspend fun finalizeItem(item: DownloadItem, rawFile: File) {
        patch(item.id) { it.copy(status = DlStatus.MERGING, progress = 99f) }

        // USER REQUEST: filename mein video ka name + selected quality
        // e.g. "My Video (1080p).mp4" / "Song (M4A).m4a"
        val final = renameWithQuality(rawFile, item)

        val isAudio = item.mimeHint == "audio"
        val saved = MediaSaver.save(appCtx, final, isAudio)
        val size = final.length()
        if (saved != null) {
            val entry = HistoryEntry(
                id = item.id,
                title = item.title,
                thumbnailUrl = item.thumbnailUrl,
                filePath = saved.second,
                mime = MediaSaver.mimeOf(final.name, isAudio),
                sizeBytes = size,
                completedAtMs = System.currentTimeMillis(),
                url = item.url,
                formatLabel = item.formatLabel
            )
            _history.value = listOf(entry) + _history.value
        }
        patch(item.id) {
            it.copy(
                status = DlStatus.DONE,
                progress = 100f,
                downloadedBytes = size,
                totalBytes = size,
                filePath = saved?.second
            )
        }
        // v2.2.1: leftover .fNNN parts + .part fragments hatao (aadha GB bhi jama
        // ho sakta tha filesDir mein) — jo file save hui hi usko rehne do
        cleanupParts(final.parentFile, keep = final)
        delay(1200)
        _active.value = _active.value.filterNot { it.id == item.id }
        persist()
    }

    /** Transient error par EK automatic retry (clientArgs fresh), permanent par turant fail */
    private suspend fun handleFailure(item: DownloadItem, rawErr: String, attempt: Int) {
        val permanent = listOf(
            "does not exist", "private", "unsupported url", "video unavailable",
            "has been removed", "requested format", "copyright"
        ).any { rawErr.lowercase(Locale.ROOT).contains(it) }
        if (!permanent && attempt < 2) {
            Log.w(TAG, "retrying download (attempt 2): ${rawErr.takeLast(120)}")
            patch(item.id) { it.copy(status = DlStatus.QUEUED, progress = 0f, error = null) }
            delay(1500)
            executeWithRetry(item.copy(clientArgs = null), attempt = 2)
            return
        }
        fail(item, UrlUtils.friendlyEngineError(rawErr))
    }

    /** Output ko "Title (Quality).ext" mein rename — MediaStore wahi naam dikhega */
    private fun renameWithQuality(src: File, item: DownloadItem): File {
        val ext = src.name.substringAfterLast('.', "mp4")
        val tag = UrlUtils.qualityTag(item.height, item.mimeHint == "audio", item.formatLabel)
        var base = UrlUtils.sanitizeFileName(item.title)
        var dest = File(src.parentFile, "$base ($tag).$ext")
        var n = 2
        while (dest.exists() && dest.absolutePath != src.absolutePath) {
            dest = File(src.parentFile, "$base ($tag) •$n.$ext")
            n++
        }
        return try {
            if (src.renameTo(dest)) dest else src
        } catch (_: Exception) {
            src
        }
    }

    private fun onUpdateLine(id: String, progress: Float, etaSec: Long, line: String) {
        lastActivityMs[id] = System.currentTimeMillis()
        // Real total size line se nikalo — "of 167.00MiB" — estimate ko replace karo
        var total = -1L
        var speed = -1L
        try {
            val ofRx = Regex("""of\s+~?\s*([\d.]+)(KiB|MiB|GiB)""")
            ofRx.find(line)?.let { m ->
                val v = m.groupValues[1].toDouble()
                total = when (m.groupValues[2]) {
                    "KiB" -> (v * 1024).toLong()
                    "GiB" -> (v * 1024 * 1024 * 1024).toLong()
                    else -> (v * 1024 * 1024).toLong()
                }
            }
            val spRx = Regex("""at\s+([\d.]+)(KiB|MiB|GiB)/s""")
            spRx.find(line)?.let { m ->
                val v = m.groupValues[1].toDouble()
                speed = when (m.groupValues[2]) {
                    "KiB" -> (v * 1024).toLong()
                    "GiB" -> (v * 1024 * 1024 * 1024).toLong()
                    else -> (v * 1024 * 1024).toLong()
                }
            }
        } catch (_: Exception) { }

        val merging = line.contains("[Merger]", true) || line.contains("[ExtractAudio]", true)
        patch(id) {
            it.copy(
                status = if (merging) DlStatus.MERGING else DlStatus.DOWNLOADING,
                progress = progress.coerceIn(0f, 100f),
                etaSec = etaSec,
                speedBps = speed,
                totalBytes = if (total > 0) total else it.totalBytes,
                downloadedBytes = if (total > 0) (total * progress / 100f).toLong() else it.downloadedBytes
            )
        }
    }

    private fun findOutput(dir: File, item: DownloadItem, before: Set<String>): File? {
        val all = dir.listFiles()?.filter { it.isFile } ?: return null
        val newFiles = all.filter { it.absolutePath !in before && it.length() > 0 }
        // v2.2 FIX: extension preference — merge kisi wajah se skip ho jaye to
        // bhi VIDEO request par VIDEO file hi mile (pehle newest uthata tha,
        // aur audio stream baad mein download hoti hai -> 2MB audio pick ho jata tha!)
        val wantAudio = item.mimeHint == "audio"
        val goodExts = if (wantAudio) AUDIO_EXTS else VIDEO_EXTS
        newFiles.filter { it.extension.lowercase(Locale.ROOT) in goodExts }
            .maxByOrNull { it.lastModified() }
            ?.let { return it }
        // 2) Koi matching-ext naya file nahi — koi bhi naya (last resort)
        newFiles.maxByOrNull { it.lastModified() }
            ?.let { return it }
        // 3) Fallback: title/id se match
        val urlId = item.url.substringAfterLast("/").substringBefore("?")
            .takeIf { it.length in 5..20 && !it.contains('.') }
        return all.filter { f ->
            f.name.contains("[") && f.name.contains("]") &&
                (item.title.take(20).let { t -> t.isNotBlank() && f.name.startsWith(UrlUtils.sanitizeFileName(t).take(20)) } ||
                    (urlId != null && f.name.contains("[$urlId]")))
        }.maxByOrNull { it.lastModified() }
            ?: all.maxByOrNull { it.lastModified() }
    }

    // ================= v2.2.1 salvage layer =================

    /**
     * Download ke baad ka kuch bhi kharab ho to yahan se deliverable nikalo.
     * Order: (1) complete merged file snapshot-diff se, (2) parts ko khud merge.
     * Video request par audio-only file KABHI nahi (user ka original 2MB bug).
     */
    private suspend fun salvageDeliverable(dir: File, item: DownloadItem, before: Set<String>): File? {
        val newFiles = dir.listFiles()
            ?.filter { it.isFile && it.absolutePath !in before && it.length() > 0 }
            ?: return null
        val wantAudio = item.mimeHint == "audio"
        if (wantAudio) {
            // Audio item: conversion (mp3) fail hua ho to raw m4a part bhi chalega
            return newFiles.filter { it.extension.lowercase(Locale.ROOT) in AUDIO_EXTS }
                .maxByOrNull { it.lastModified() }
        }
        // Video: complete file (part marker NAHI hai naam mein) prefer karo
        newFiles.filter {
            it.extension.lowercase(Locale.ROOT) in VIDEO_EXTS && !PART_RX.matches(it.name)
        }.maxByOrNull { it.lastModified() }?.let { return it }
        // Parts hain to khud merge karo
        return salvageMerge(item, dir)
    }

    /**
     * yt-dlp ka merge fail/skip ho gaya? Video-only + audio-only parts ko
     * AAPKE app ke libffmpeg.so se merge karo — timeout ke sath, full control.
     */
    private fun salvageMerge(item: DownloadItem, dir: File): File? {
        if (item.mimeHint != "video") return null
        if (Engine.ffmpegExecutable(appCtx) == null) return null

        val partFiles = dir.listFiles()
            ?.filter { it.isFile && it.length() > 0 && PART_RX.matches(it.name) }
            ?: return null
        if (partFiles.isEmpty()) return null

        // Newest group pehle — same video ke parts ka common base
        val newest = partFiles.maxByOrNull { it.lastModified() } ?: return null
        val base = PART_RX.find(newest.name)?.groupValues?.get(1) ?: return null
        val group = partFiles.filter { PART_RX.find(it.name)?.groupValues?.get(1) == base }
        if (group.size < 2) return null

        var video: File? = null
        var audio: File? = null
        var anyProbe = false
        for (f in group.sortedByDescending { it.length() }) {
            val s = probeStreams(f)
            if (s == null) continue
            anyProbe = true
            if (s.first && !s.second && video == null) video = f
            else if (s.second && !s.first && audio == null) audio = f
        }
        if (!anyProbe) {
            // ffprobe unavailable — size heuristic: badi = video, doosri = audio
            val sorted = group.sortedByDescending { it.length() }
            if (sorted.size >= 2) {
                video = sorted[0]
                audio = sorted[1]
            }
        }
        val v = video ?: return null
        val a = audio ?: return null

        // Out name: parts ka base — collision par suffix
        var out = File(dir, "$base.mp4")
        var n = 2
        while (out.exists()) { out = File(dir, "$base (merged $n).mp4"); n++ }

        val merged = runMerge(v, a, out, "mp4")
            ?: run {
                var out2 = File(dir, "$base.mkv")
                var k = 2
                while (out2.exists()) { out2 = File(dir, "$base (merged $k).mkv"); k++ }
                runMerge(v, a, out2, "mkv")
            }
            ?: return null

        // Sanity: merged file video part jitni to honi hi chahiye (+ audio)
        return if (merged.length() >= (v.length() * 0.9)) merged else {
            merged.delete()
            null
        }
    }

    /** ffmpeg stream-copy merge — (video, audio) -> container, timeout protected */
    private fun runMerge(v: File, a: File, out: File, format: String): File? {
        val args = mutableListOf(
            "-y", "-i", v.absolutePath, "-i", a.absolutePath,
            "-c", "copy", "-map", "0:v:0", "-map", "1:a:0"
        )
        if (format == "mp4") {
            args.add("-movflags")
            args.add("+faststart")
        }
        args.add("-f"); args.add(format)
        args.add(out.absolutePath)

        val code = runNativeTool(args, SALVAGE_TIMEOUT_MS)
        return if (code != null && code == 0 && out.exists() && out.length() > 0) out
        else {
            out.delete()
            null
        }
    }

    /** ffprobe se pata karo file mein video/audio stream kaunsa hai — (hasVideo, hasAudio) */
    private fun probeStreams(f: File): Pair<Boolean, Boolean>? {
        val ffprobe = Engine.ffprobeExecutable(appCtx) ?: return null
        val out = StringBuilder()
        val code = runNativeToolCapturing(
            ffprobe,
            listOf(
                "-v", "error",
                "-show_entries", "stream=codec_type",
                "-of", "csv=p=0", f.absolutePath
            ), 30_000L, out
        ) ?: return null
        if (code != 0) return null
        val text = out.toString().lowercase(Locale.ROOT)
        return (text.contains("video") to text.contains("audio"))
    }

    /** Bootstrap ffmpeg chalao — timeout ke sath */
    private fun runNativeTool(args: List<String>, timeoutMs: Long): Int? {
        val ffmpeg = Engine.ffmpegExecutable(appCtx) ?: return null
        return runNativeToolCapturing(ffmpeg, args, timeoutMs, null)
    }

    private fun runNativeToolCapturing(exe: File, args: List<String>, timeoutMs: Long, capture: StringBuilder?): Int? {
        return try {
            val pb = ProcessBuilder(listOf(exe.absolutePath) + args)
                .redirectErrorStream(true)
            val env = pb.environment()
            env["LD_LIBRARY_PATH"] = Engine.ffmpegLdLibraryPath(appCtx)
            env["TMPDIR"] = appCtx.cacheDir.absolutePath
            val p = pb.start()
            val reader = Thread {
                try {
                    p.inputStream.bufferedReader().forEachLine { line ->
                        if (capture != null && capture.length < 64_000) capture.appendLine(line)
                    }
                } catch (_: Exception) { }
            }
            reader.isDaemon = true
            reader.start()
            val done = p.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
            if (!done) {
                p.destroy()
                reader.join(2000)
                return null
            }
            reader.join(2000)
            p.exitValue()
        } catch (e: Exception) {
            Log.w(TAG, "native tool failed: ${e.message}")
            null
        }
    }

    /** Success ke baad transient files clean karo — .fNNN parts, .part, .ytdl — 'keep' ko chhod ke */
    private fun cleanupParts(dir: File?, keep: File?) {
        if (dir == null) return
        dir.listFiles()?.forEach { f ->
            if (!f.isFile) return@forEach
            if (keep != null && f.absolutePath == keep.absolutePath) return@forEach
            val name = f.name
            val transient = PART_RX.matches(name) ||
                name.endsWith(".part") ||
                name.endsWith(".ytdl") ||
                name.contains(".part-Frag")
            if (transient) {
                try { f.delete() } catch (_: Exception) { }
            }
        }
    }

    /** 10 min se zyada koi line nahi aayi → process kill (catch side salvage karega) */
    private fun startWatchdog(id: String): Job = appScope.launch {
        try {
            while (isActive) {
                delay(30_000)
                val last = lastActivityMs[id] ?: return@launch
                if (System.currentTimeMillis() - last > INACTIVITY_TIMEOUT_MS) {
                    watchdogFired[id] = true
                    Log.w(TAG, "watchdog: ${INACTIVITY_TIMEOUT_MS / 60000}min inactivity — killing $id")
                    try { YoutubeDL.getInstance().destroyProcessById(id) } catch (_: Exception) { }
                    return@launch
                }
            }
        } catch (_: Exception) { }
    }

    private val VIDEO_EXTS = setOf("mp4", "mkv", "webm", "mov", "m4v", "3gp", "avi", "flv", "ts")
    private val AUDIO_EXTS = setOf("m4a", "mp3", "opus", "ogg", "wav", "aac", "flac")

    private fun fail(item: DownloadItem, msg: String) {
        patch(item.id) { it.copy(status = DlStatus.FAILED, error = msg) }
        persist()
    }

    private fun patch(id: String, transform: (DownloadItem) -> DownloadItem) {
        _active.value = _active.value.map { if (it.id == id) transform(it) else it }
        if (_active.value.none { it.id == id }) return
        persistThrottled()
    }

    private fun persistThrottled() {
        if (persistJob?.isActive == true) return
        persistJob = appScope.launch {
            delay(1500)
            Prefs.saveDownloads(appCtx, _active.value, _history.value)
        }
    }

    private fun persist() {
        if (!::appCtx.isInitialized) return
        appScope.launch { Prefs.saveDownloads(appCtx, _active.value, _history.value) }
    }
}
