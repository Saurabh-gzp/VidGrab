package com.vidgrab.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * v2.2.1 salvage/merge layer tests:
 *  - PART_RX pairing logic (yt-dlp "Title [id].f137.mp4" naming)
 *  - extension classification
 *  - Fetcher merge-safe selectors
 */
class SalvageMergeTest {

    // DownloadRepository.PART_RX ka mirror — same behavior must match
    private val PART_RX = Regex("""^(.+)\.f\d+\.[A-Za-z0-9]+$""")
    private val VIDEO_EXTS = setOf("mp4", "mkv", "webm", "mov", "m4v", "3gp", "avi", "flv", "ts")
    private val AUDIO_EXTS = setOf("m4a", "mp3", "opus", "ogg", "wav", "aac", "flac")

    @Test
    fun partRx_matchesYtDlpPartNames() {
        val m = PART_RX.matchEntire("Big Buck Bunny 4K (Official) [abc-_123].f137.mp4")
        assertTrue(m != null)
        assertEquals("Big Buck Bunny 4K (Official) [abc-_123]", m!!.groupValues[1])
        assertEquals("mp4", m.value.substringAfterLast('.'))
    }

    @Test
    fun partRx_matchesAudioParts() {
        assertTrue(PART_RX.matchEntire("Song [id1].f140.m4a") != null)
        assertTrue(PART_RX.matchEntire("Song [id1].f251.webm") != null)
        assertTrue(PART_RX.matchEntire("Song [id1].f251.opus") != null)
    }

    @Test
    fun partRx_rejectsMergedAndNormalFiles() {
        // merged output — no .fNNN marker
        assertFalse(PART_RX.matches("Big Buck Bunny 4K (Official) [abc-_123].mp4"))
        assertFalse(PART_RX.matches("Song (M4A).m4a"))
        assertFalse(PART_RX.matches("Title (1080p) •2.mp4"))
        // part files with dots in base still match with full base captured
        val m = PART_RX.matchEntire("My.Video (2024) [id9].f248.webm")
        assertTrue(m != null)
        assertEquals("My.Video (2024) [id9]", m!!.groupValues[1])
    }

    @Test
    fun baseGrouping_keepsSameVideoPartsTogether() {
        val names = listOf(
            "Video A [id1].f137.mp4",
            "Video A [id1].f140.m4a",
            "Video B [id2].f137.mp4"
        )
        val bases = names.mapNotNull { PART_RX.matchEntire(it)?.groupValues?.get(1) }.toSet()
        assertEquals(2, bases.size)
        assertEquals(
            2,
            names.count { PART_RX.matchEntire(it)!!.groupValues[1] == "Video A [id1]" }
        )
    }

    @Test
    fun extClassification_separatesVideoAndAudio() {
        val videoPart = "T [id].f137.mp4"
        val audioPart = "T [id].f140.m4a"
        val webmVideo = "T [id].f248.webm"
        val webmAudio = "T [id].f251.webm"

        fun extOf(n: String) = n.substringAfterLast('.').lowercase()
        assertTrue(extOf(videoPart) in VIDEO_EXTS)
        assertTrue(extOf(audioPart) in AUDIO_EXTS)
        // webm is ambiguous — probeStreams classifies; regex never mislabels
        assertTrue(extOf(webmVideo) in VIDEO_EXTS)
        assertTrue(extOf(webmAudio) in VIDEO_EXTS) // handled by ffprobe, not ext
    }

    @Test
    fun salvageSkips_whenNoPartMarkerPresent() {
        // dir with only completed files — salvageMerge must not run
        val dir = createTempDir("vgtest")
        try {
            val f = File(dir, "Complete [vid1].mp4").apply { writeText("x") }
            val parts = dir.listFiles()!!.filter { PART_RX.matches(it.name) }
            assertTrue(parts.isEmpty())
            assertTrue(f.exists())
        } finally {
            dir.deleteRecursively()
        }
    }

    @Test
    fun cleanupPatterns_coverTransientFiles() {
        val candidates = listOf(
            "T [id].f137.mp4",           // part — delete
            "T [id].f140.m4a",           // part — delete
            "T.mp4.part",                // partial — delete
            "T.mp4.ytdl",                // lock file — delete
            "T.mp4.part-Frag123",        // fragment — delete
            "T (1080p).mp4",             // final — KEEP
            "T [id].mp4"                 // merged pre-rename — KEEP
        )
        fun isTransient(name: String) = PART_RX.matches(name) ||
            name.endsWith(".part") || name.endsWith(".ytdl") || name.contains(".part-Frag")
        val toDelete = candidates.filter { isTransient(it) }
        assertEquals(5, toDelete.size)
        assertTrue("T (1080p).mp4" !in toDelete)
        assertTrue("T [id].mp4" !in toDelete)
    }

    // ---------- Fetcher selector sanity (merge-safe ordering) ----------

    @Test
    fun selector_avc1FirstFor1080p() {
        val sel = "bv*[vcodec^=avc1][height<=1080]+ba[acodec^=mp4a]/bestvideo[height<=1080]+bestaudio/best[height<=1080]/best"
        assertTrue(sel.startsWith("bv*[vcodec^=avc1]"))
        assertTrue(sel.endsWith("/best"))
    }

    @Test
    fun selector_bestKeepsFallbackChain() {
        val sel = "bv*[vcodec^=avc1]+ba[acodec^=mp4a]/bestvideo*+bestaudio/best/bestvideo+bestaudio"
        // final fallback always present
        assertTrue(sel.contains("/best"))
        assertTrue(sel.contains("bestvideo*+bestaudio"))
    }
}
