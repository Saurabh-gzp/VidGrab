package com.vidgrab.app.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vidgrab.app.core.UpdateState
import com.vidgrab.app.ui.components.animatedAuroraBrush
import com.vidgrab.app.ui.components.glassCard
import com.vidgrab.app.ui.theme.LocalAurora
import com.vidgrab.app.util.UrlUtils

/**
 * Splash-style full-screen overlay — sirf tab dikhta hai jab
 * engine ka update SACH MEIN download ho raha ho.
 * App close kar do to foreground service poora karta rahega.
 */
@Composable
fun UpdateOverlay(state: UpdateState) {
    val aurora = LocalAurora.current
    val updating = state is UpdateState.Updating
    val progress = (state as? UpdateState.Updating)?.progress ?: 100f
    val eta = (state as? UpdateState.Updating)?.etaSec ?: -1L
    val line = (state as? UpdateState.Updating)?.line ?: "All set"

    Box(
        Modifier
            .fillMaxSize()
            .background(aurora.bg)
    ) {
        // Ambient aurora glow
        val transition = rememberInfiniteTransition(label = "glow")
        val glow by transition.animateFloat(
            initialValue = 0f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(2600), RepeatMode.Reverse),
            label = "g"
        )
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(aurora.violet.copy(alpha = 0.16f + glow * 0.10f), Color.Transparent),
                    center = Offset(size.width * 0.2f, size.height * 0.16f),
                    radius = size.width * 0.9f
                ),
                radius = size.width * 0.9f,
                center = Offset(size.width * 0.2f, size.height * 0.16f)
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(aurora.cyan.copy(alpha = 0.12f + (1 - glow) * 0.08f), Color.Transparent),
                    center = Offset(size.width * 0.85f, size.height * 0.8f),
                    radius = size.width
                ),
                radius = size.width,
                center = Offset(size.width * 0.85f, size.height * 0.8f)
            )
        }

        Column(
            Modifier
                .fillMaxWidth()
                .align(Alignment.Center)
                .padding(horizontal = 34.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Logo mark
            Box(
                Modifier
                    .size(86.dp)
                    .glassCard(highlight = true),
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.size(44.dp)) {
                    val stroke = 8.dp.toPx()
                    drawArc(
                        brush = Brush.sweepGradient(listOf(aurora.violet, aurora.cyan, aurora.violet)),
                        startAngle = -90f,
                        sweepAngle = if (updating) 360f * (progress / 100f).coerceIn(0.03f, 1f) else 360f,
                        useCenter = false,
                        style = androidx.compose.ui.graphics.drawscope.Stroke(stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                    )
                    drawLine(
                        brush = aurora.gradient,
                        start = Offset(size.width * 0.5f, size.height * 0.28f),
                        end = Offset(size.width * 0.5f, size.height * 0.62f),
                        strokeWidth = stroke,
                        cap = androidx.compose.ui.graphics.StrokeCap.Round
                    )
                    drawLine(
                        brush = aurora.gradient,
                        start = Offset(size.width * 0.32f, size.height * 0.47f),
                        end = Offset(size.width * 0.5f, size.height * 0.66f),
                        strokeWidth = stroke,
                        cap = androidx.compose.ui.graphics.StrokeCap.Round
                    )
                    drawLine(
                        brush = aurora.gradient,
                        start = Offset(size.width * 0.68f, size.height * 0.47f),
                        end = Offset(size.width * 0.5f, size.height * 0.66f),
                        strokeWidth = stroke,
                        cap = androidx.compose.ui.graphics.StrokeCap.Round
                    )
                }
            }

            Spacer(Modifier.height(28.dp))

            if (updating) {
                Text(
                    "UPDATING ENVIRONMENT",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = aurora.text
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Getting the best quality engine ready…",
                    style = MaterialTheme.typography.bodyMedium,
                    color = aurora.textDim
                )

                Spacer(Modifier.height(26.dp))

                // Progress bar
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(9.dp)
                        .clip(RoundedCornerShape(50))
                        .background(aurora.glass)
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth((progress / 100f).coerceIn(0.02f, 1f))
                            .height(9.dp)
                            .clip(RoundedCornerShape(50))
                            .background(animatedAuroraBrush())
                    )
                }

                Spacer(Modifier.height(12.dp))

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "${progress.toInt()}%",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = aurora.cyan
                    )
                    Text(
                        if (eta in 0..86400) UrlUtils.formatEta(eta) else "almost there…",
                        style = MaterialTheme.typography.labelLarge,
                        color = aurora.textDim
                    )
                }

                Spacer(Modifier.height(18.dp))

                Text(
                    line.takeLast(90),
                    style = MaterialTheme.typography.bodySmall,
                    color = aurora.textFaint,
                    maxLines = 2
                )
            } else {
                // Done
                Text(
                    "You're up to date",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = aurora.text
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Everything is ready.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = aurora.success
                )
            }
        }
    }
}
