package com.vidgrab.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vidgrab.app.core.DownloadRepository
import com.vidgrab.app.core.Prefs
import com.vidgrab.app.core.UpdateManager
import com.vidgrab.app.core.UpdateState
import com.vidgrab.app.util.MediaSaver
import com.vidgrab.app.ui.components.glassCard
import com.vidgrab.app.ui.components.pressScale
import com.vidgrab.app.ui.components.animatedAuroraBrush
import com.vidgrab.app.ui.components.VidIcons
import com.vidgrab.app.ui.screens.DownloadsScreen
import com.vidgrab.app.ui.screens.HomeScreen
import com.vidgrab.app.ui.screens.SettingsScreen
import com.vidgrab.app.ui.theme.LocalAurora
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Filled.Home),
    DOWNLOADS("Downloads", com.vidgrab.app.ui.components.VidIcons.Download),
    SETTINGS("Settings", Icons.Filled.Settings)
}

@Composable
fun AppRoot(
    themeFlow: kotlinx.coroutines.flow.Flow<Prefs.ThemeMode>,
    incomingUrl: String?,
    onUrlConsumed: () -> Unit
) {
    val theme by themeFlow.collectAsState(initial = Prefs.ThemeMode.System)
    val updateState by UpdateManager.state.collectAsState()
    val rootCtx = androidx.compose.ui.platform.LocalContext.current

    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }

    // v2.2: All Files Access — top-level VidGrab/{Video,Audio} folder ke liye.
    // Launch par ek baar poochho (grant na ho to); downloads phir bhi
    // MediaStore fallback se chalte rahenge.
    var showStorageDialog by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(1100)
        if (!MediaSaver.hasAllFilesAccess(rootCtx)) showStorageDialog = true
    }
    if (showStorageDialog) {
        val aurora = LocalAurora.current
        AlertDialog(
            onDismissRequest = { showStorageDialog = false },
            containerColor = aurora.surface,
            titleContentColor = aurora.text,
            textContentColor = aurora.textDim,
            shape = RoundedCornerShape(22.dp),
            title = { Text("Save in VidGrab folder") },
            text = {
                Text(
                    "Allow VidGrab to manage all files so every download is saved in a " +
                        "VidGrab folder in your storage — with Video and Audio subfolders " +
                        "inside it. You just flip one switch on the next screen."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showStorageDialog = false
                    try {
                        rootCtx.startActivity(
                            MediaSaver.allFilesAccessIntent(rootCtx)
                                .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (_: Exception) { }
                }) {
                    Text("Allow", color = aurora.violet, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showStorageDialog = false }) {
                    Text("Not now", color = aurora.textDim)
                }
            }
        )
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding() // FIX: content status bar ke neeche na jaye (edge-to-edge)
    ) {
        AnimatedContent(
            targetState = tab,
            transitionSpec = {
                val dir = if (targetState.ordinal >= initialState.ordinal) 1 else -1
                (slideInHorizontally(tween(260)) { it / 4 * dir } + fadeIn(tween(220)))
                    .togetherWith(slideOutHorizontally(tween(200)) { -it / 5 * dir } + fadeOut(tween(160)))
            },
            label = "tab",
            modifier = Modifier.weight(1f)
        ) { t ->
            when (t) {
                Tab.HOME -> HomeScreen(
                    vm = androidx.lifecycle.viewmodel.compose.viewModel<HomeViewModel>(),
                    incomingUrl = incomingUrl.takeIf { t == Tab.HOME },
                    onUrlConsumed = onUrlConsumed
                )
                Tab.DOWNLOADS -> DownloadsScreen()
                Tab.SETTINGS -> SettingsScreen(
                    themeFlow = themeFlow,
                    onTheme = { mode ->
                        DownloadRepository.appScope.launch {
                            Prefs.setTheme(rootCtx.applicationContext, mode)
                        }
                    }
                )
            }
        }

        // Floating glass nav bar
        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 60.dp)
                .padding(bottom = 14.dp + WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding())
        ) {
            val activeCount by DownloadRepository.active.collectAsState()
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(62.dp)
                    .glassCard()
                    .imePadding(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Tab.entries.forEach { t ->
                    NavItem(
                        tab = t,
                        selected = t == tab,
                        badge = if (t == Tab.DOWNLOADS) activeCount.size else 0
                    ) { tab = t }
                }
            }
        }
    }

    // Update overlay — sirf jab ACTUAL update chal raha ho
    AnimatedVisibility(
        visible = updateState is UpdateState.Updating || updateState is UpdateState.Done,
        enter = fadeIn(),
        exit = fadeOut(tween(500))
    ) {
        UpdateOverlay(updateState)
    }

    // Done state auto-dismiss
    LaunchedEffect(updateState) {
        if (updateState is UpdateState.Done) {
            delay(1100)
            UpdateManager.resetToIdle()
        } else if (updateState is UpdateState.Failed) {
            delay(1500)
            UpdateManager.resetToIdle()
        }
    }
}

@Composable
private fun NavItem(tab: Tab, selected: Boolean, badge: Int, onClick: () -> Unit) {
    val aurora = LocalAurora.current
    val interaction = remember { MutableInteractionSource() }
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val iconScale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (selected) 1.15f else 1f,
        animationSpec = androidx.compose.animation.core.spring(
            dampingRatio = androidx.compose.animation.core.Spring.DampingRatioMediumBouncy,
            stiffness = androidx.compose.animation.core.Spring.StiffnessMedium
        ),
        label = "navIcon"
    )
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .pressScale(interaction)
            .clickable(interactionSource = interaction, indication = null, onClick = {
                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                onClick()
            })
            .padding(vertical = 6.dp)
    ) {
        Box {
            Box(
                Modifier
                    .size(40.dp, 30.dp)
                    .clip(RoundedCornerShape(50))
                    .then(
                        if (selected) Modifier.background(animatedAuroraBrush())
                        else Modifier
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    tab.icon,
                    contentDescription = tab.label,
                    tint = if (selected) Color.White else aurora.textDim,
                    modifier = Modifier
                        .size(19.dp)
                        .scale(iconScale)
                )
            }
            if (badge > 0) {
                Box(
                    Modifier
                        .offset(x = 15.dp, y = (-3).dp)
                        .size(15.dp)
                        .clip(RoundedCornerShape(50))
                        .background(aurora.magenta),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        badge.coerceAtMost(9).toString(),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        fontSize = androidx.compose.ui.unit.TextUnit(9f, androidx.compose.ui.unit.TextUnitType.Sp)
                    )
                }
            }
        }
        Text(
            tab.label,
            style = MaterialTheme.typography.labelSmall,
            color = if (selected) aurora.text else aurora.textDim,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
        )
    }
}

/** Settings se theme change ka bridge (composition-safe) */
