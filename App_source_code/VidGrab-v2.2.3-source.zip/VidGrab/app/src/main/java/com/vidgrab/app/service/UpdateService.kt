package com.vidgrab.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.vidgrab.app.MainActivity
import com.vidgrab.app.R
import com.vidgrab.app.core.Engine
import com.vidgrab.app.core.UpdateManager
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

/**
 * Engine update service — app band hone par bhi update poora karta hai.
 * Real progress: pehle asset download khud karte hain (% + ETA),
 * phir library ka atomic swap + re-init.
 */
class UpdateService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        createChannel(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        scope.launch {
            try {
                Engine.await()
                UpdateManager.setProgress(2f, -1, "Checking latest version…")

                val release = UpdateManager.fetchLatestRelease()
                val installed = Engine.engineVersion(applicationContext)
                if (release == null || installed == null) {
                    UpdateManager.resetToIdle()
                    stopSelf()
                    return@launch
                }
                val (tag, assetUrl, assetSize) = release
                if (!UpdateManager.isNewer(tag, installed)) {
                    UpdateManager.resetToIdle()
                    stopSelf()
                    return@launch
                }

                // Phase 1: asset download — real progress
                val dest = File(cacheDir, "ytdlp_update.bin")
                val started = System.currentTimeMillis()
                val okDl = UpdateManager.downloadAsset(assetUrl, dest) { read, total ->
                    val pct = if (total > 0) read.toFloat() / total * 84f else 0f
                    val speed = read / ((System.currentTimeMillis() - started).coerceAtLeast(1) / 1000f)
                    val eta = if (total > 0 && speed > 0) ((total - read) / speed).toLong() else -1L
                    UpdateManager.setProgress((1f + pct).coerceIn(1f, 85f), eta, "Downloading update (${if (total > 0) "${read * 100 / total}%" else "…"})")
                }
                if (!okDl) {
                    dest.delete()
                    UpdateManager.markFailed()
                    delay(1600)
                    UpdateManager.resetToIdle()
                    stopSelf()
                    return@launch
                }

                // Phase 2: swap + verify — pre-downloaded binary ko seedha install karo
                // (library ka updateYoutubeDL dobara 3MB download karta — double download hataya)
                UpdateManager.setProgress(88f, -1, "Installing update…")
                var swapped = false
                try {
                    swapped = Engine.installBinary(applicationContext, dest, tag)
                } catch (_: Exception) {
                    swapped = false
                }
                if (!swapped) {
                    // Fallback: library ka apna updater (network se)
                    try {
                        YoutubeDL.getInstance().updateYoutubeDL(applicationContext, YoutubeDL.UpdateChannel.STABLE)
                        swapped = true
                    } catch (_: Exception) {
                        swapped = false
                    }
                }
                dest.delete()
                // VERIFY: version sach mein badha?
                if (swapped) {
                    val newVer = Engine.engineVersion(applicationContext)
                    swapped = newVer != null && UpdateManager.isNewer(tag, newVer).not() && newVer != installed
                    if (!swapped && newVer == tag.removePrefix("v")) swapped = true
                }
                if (swapped) {
                    UpdateManager.setProgress(100f, 0, "Ready")
                    UpdateManager.markDone()
                } else {
                    UpdateManager.markFailed()
                    delay(1600)
                    UpdateManager.resetToIdle()
                }
            } catch (_: Exception) {
                UpdateManager.markFailed()
                delay(1600)
                UpdateManager.resetToIdle()
            }
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val notif = buildNotification("0%", 0f)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun buildNotification(pct: String, progress: Float): Notification {
        val contentIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle(getString(R.string.notif_updating))
            .setContentText(pct)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(contentIntent)
            .setProgress(100, progress.toInt(), false)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    private fun updateProgress(progress: Float) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification("${progress.toInt()}%", progress))
    }

    override fun onTimeout(startId: Int, fgsType: Int) {
        stopSelf()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_ID = "vidgrab_updates"
        const val NOTIF_ID = 102

        fun createChannel(ctx: Context) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(
                CHANNEL_ID, ctx.getString(R.string.notif_channel_updates),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = ctx.getString(R.string.notif_channel_updates_desc)
                setShowBadge(false)
            }
            nm.createNotificationChannel(ch)
        }
    }
}
