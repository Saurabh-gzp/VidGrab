package com.vidgrab.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vidgrab.app.ui.theme.LocalAurora

/** Press spring scale */
fun Modifier.pressScale(interaction: MutableInteractionSource): Modifier = composed {
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "press"
    )
    this.scale(scale)
}

/** Infinite animated aurora gradient brush */
@Composable
fun animatedAuroraBrush(): Brush {
    val aurora = LocalAurora.current
    val transition = rememberInfiniteTransition(label = "aurora")
    val shift by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3600, easing = LinearEasing), RepeatMode.Reverse),
        label = "shift"
    )
    return Brush.linearGradient(
        colors = listOf(aurora.violet, aurora.magenta, aurora.cyan, aurora.violet),
        start = Offset(shift * 600f, shift * 200f),
        end = Offset(200f + (1 - shift) * 500f, 400f + shift * 300f)
    )
}

/** Glassy card */
fun Modifier.glassCard(highlight: Boolean = false): Modifier = composed {
    val aurora = LocalAurora.current
    this
        .clip(RoundedCornerShape(22.dp))
        .background(if (highlight) aurora.glass.copy(alpha = aurora.glass.alpha * 1.6f) else aurora.glass)
        .border(
            width = 1.dp,
            brush = if (highlight) Brush.linearGradient(listOf(aurora.violet.copy(alpha = 0.5f), aurora.cyan.copy(alpha = 0.25f)))
            else Brush.linearGradient(listOf(aurora.glassBorder, aurora.glassBorder.copy(alpha = 0.4f))),
            shape = RoundedCornerShape(22.dp)
        )
}

/** Shimmer placeholder */
@Composable
fun ShimmerBox(modifier: Modifier = Modifier, corner: Int = 18) {
    val aurora = LocalAurora.current
    val transition = rememberInfiniteTransition(label = "shimmer")
    val x by transition.animateFloat(
        initialValue = -400f, targetValue = 1200f,
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing)),
        label = "x"
    )
    Box(
        modifier
            .clip(RoundedCornerShape(corner.dp))
            .background(aurora.glass)
            .drawBehind {
                drawRect(
                    Brush.linearGradient(
                        colors = listOf(
                            Color.Transparent,
                            aurora.glassBorder.copy(alpha = 0.5f),
                            Color.Transparent
                        ),
                        start = Offset(x, 0f), end = Offset(x + 300f, 220f)
                    )
                )
            }
    )
}

/** Circular progress ring with aurora gradient — indeterminate = spinning arc */
@Composable
fun ProgressRing(
    progress: Float,
    sizeDp: Int = 46,
    stroke: Int = 5,
    indeterminate: Boolean = false,
    content: @Composable (() -> Unit)? = null
) {
    val aurora = LocalAurora.current
    // Processing phase ke liye — arc ghoomta rehta hai
    val spin by rememberInfiniteTransition(label = "ringSpin").animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing)),
        label = "spinAngle"
    )
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.size(sizeDp.dp)
    ) {
        androidx.compose.foundation.Canvas(Modifier.size(sizeDp.dp)) {
            val strokePx = stroke.dp.toPx()
            drawArc(
                color = aurora.glassBorder,
                startAngle = -90f, sweepAngle = 360f, useCenter = false,
                style = androidx.compose.ui.graphics.drawscope.Stroke(strokePx)
            )
            if (indeterminate) {
                drawArc(
                    brush = Brush.sweepGradient(listOf(aurora.violet, aurora.cyan, aurora.violet)),
                    startAngle = spin - 90f, sweepAngle = 110f,
                    useCenter = false,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(strokePx, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                )
            } else {
                drawArc(
                    brush = Brush.sweepGradient(listOf(aurora.violet, aurora.cyan, aurora.violet)),
                    startAngle = -90f, sweepAngle = 360f * (progress / 100f).coerceIn(0f, 1f),
                    useCenter = false,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(strokePx, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                )
            }
        }
        content?.invoke()
    }
}

/** Big gradient CTA button — glow + shine sweep + spring press (v2.1 premium feel) */
@Composable
fun GradientButton(
    text: String,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    loading: Boolean = false,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val aurora = LocalAurora.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val brush = if (enabled) animatedAuroraBrush() else Brush.linearGradient(listOf(aurora.textFaint, aurora.textFaint))

    // Shine sweep — press par ek light streak left→right guzarti hai
    val shine = rememberInfiniteTransition(label = "shine")
    val shineX by shine.animateFloat(
        initialValue = -300f, targetValue = 900f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart),
        label = "shineX"
    )
    // Glow breathing
    val glowPulse by shine.animateFloat(
        initialValue = 0.55f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1900, easing = LinearEasing), RepeatMode.Reverse),
        label = "glow"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
            .pressScale(interaction)
            .shadow(
                elevation = if (enabled) 18.dp else 4.dp,
                shape = RoundedCornerShape(18.dp),
                ambientColor = aurora.violet,
                spotColor = aurora.violet.copy(alpha = if (enabled) glowPulse * 0.9f else 0.15f)
            )
            .clip(RoundedCornerShape(18.dp))
            .background(brush)
            .drawBehind {
                if (enabled) {
                    drawRect(
                        brush = Brush.linearGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.White.copy(alpha = if (pressed) 0.38f else 0.16f),
                                Color.Transparent
                            ),
                            start = Offset(shineX, 0f),
                            end = Offset(shineX + 260f, size.height)
                        )
                    )
                }
            }
            .pointerInput(enabled) {
                if (enabled) detectTapGestures(onTap = { onClick() })
            },
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (loading) {
            Box(
                Modifier
                    .size(20.dp)
                    .graphicsLayer { rotationZ = 0f },
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.material3.CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp,
                    color = Color.White
                )
            }
            Spacer(Modifier.width(10.dp))
        } else if (icon != null) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
        }
        Text(
            text,
            color = Color.White,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )
    }
}

/** Claude-style confirmation dialog — delete ke liye */
@Composable
fun ConfirmDialog(
    title: String,
    body: String,
    confirmLabel: String = "Delete",
    dismissLabel: String = "Cancel",
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    val aurora = LocalAurora.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = aurora.surface,
        titleContentColor = aurora.text,
        textContentColor = aurora.textDim,
        shape = RoundedCornerShape(22.dp),
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = { Text(body, style = MaterialTheme.typography.bodyMedium) },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(confirmLabel, color = aurora.danger, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(dismissLabel, color = aurora.textDim)
            }
        }
    )
}

/** Empty state */
@Composable
fun EmptyState(icon: ImageVector, title: String, subtitle: String) {
    val aurora = LocalAurora.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(84.dp)
                .glassCard(),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                icon, contentDescription = null,
                tint = aurora.violet, modifier = Modifier.size(36.dp)
            )
        }
        Spacer(Modifier.height(18.dp))
        Text(title, style = MaterialTheme.typography.titleLarge, color = aurora.text)
        Spacer(Modifier.height(6.dp))
        Text(
            subtitle, style = MaterialTheme.typography.bodyMedium,
            color = aurora.textDim, modifier = Modifier.padding(horizontal = 40.dp)
        )
    }
}
