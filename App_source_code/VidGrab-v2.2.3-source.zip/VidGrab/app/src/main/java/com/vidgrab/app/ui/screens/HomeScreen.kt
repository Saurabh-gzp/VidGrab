package com.vidgrab.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.vidgrab.app.core.FormatOption
import com.vidgrab.app.ui.HomeViewModel
import com.vidgrab.app.ui.components.GradientButton
import com.vidgrab.app.ui.components.ShimmerBox
import com.vidgrab.app.ui.components.VidIcons
import com.vidgrab.app.ui.components.glassCard
import com.vidgrab.app.ui.components.pressScale
import com.vidgrab.app.ui.theme.LocalAurora
import com.vidgrab.app.util.UrlUtils

@Composable
fun HomeScreen(vm: HomeViewModel, incomingUrl: String?, onUrlConsumed: () -> Unit) {
    val aurora = LocalAurora.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberScrollState()

    LaunchedEffect(incomingUrl) {
        if (!incomingUrl.isNullOrBlank()) {
            vm.onUrlChange(incomingUrl)
            vm.fetch(incomingUrl)
            onUrlConsumed()
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(scope)
            .padding(horizontal = 20.dp)
            .imePadding()
    ) {
        Spacer(Modifier.height(14.dp))

        // Header — wordmark with gradient + ambient glow blobs
        Box {
            // Aurora glow blobs (premium depth)
            Box(
                Modifier
                    .offset(x = (-46).dp, y = (-40).dp)
                    .size(150.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(aurora.violet.copy(alpha = 0.22f), Color.Transparent)
                        )
                    )
            )
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 40.dp, y = (-10).dp)
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(aurora.cyan.copy(alpha = 0.18f), Color.Transparent)
                        )
                    )
            )
            Column {
                Text(
                    "VidGrab",
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = aurora.text
                )
                Text(
                    "Grab any video. Any quality.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = aurora.textDim
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        // URL input — glassy
        Row(
            Modifier
                .fillMaxWidth()
                .glassCard()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                VidIcons.Link, contentDescription = null,
                tint = aurora.textDim, modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(10.dp))
            androidx.compose.material3.OutlinedTextField(
                value = vm.url,
                onValueChange = { vm.onUrlChange(it) },
                placeholder = {
                    Text("Paste video link…", color = aurora.textFaint, maxLines = 1)
                },
                singleLine = true,
                colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedTextColor = aurora.text,
                    unfocusedTextColor = aurora.text,
                    cursorColor = aurora.violet,
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent
                ),
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = {
                val t = clipboard.getText()?.text
                if (!t.isNullOrBlank()) {
                    val u = UrlUtils.extractUrl(t) ?: t.trim()
                    vm.onUrlChange(u)
                }
            }) {
                Icon(
                    VidIcons.Paste, contentDescription = "Paste",
                    tint = aurora.cyan
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        // Fetch button
        val interaction = remember2()
        GradientButton(
            text = if (vm.fetching) "Fetching…" else "Fetch video",
            icon = Icons.Filled.Search,
            enabled = vm.url.isNotBlank() && !vm.fetching,
            loading = vm.fetching
        ) {
            vm.fetch()
        }

        // Platform detect chip
        if (vm.url.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val plat = UrlUtils.platformOf(vm.url)
                PlatformChip(plat, gradient = true)
                UrlUtils.PLATFORMS.filter { it != plat }.take(4).forEach { PlatformChip(it) }
            }
        }

        Spacer(Modifier.height(18.dp))

        // Error
        vm.error?.let { err ->
            Box(
                Modifier
                    .fillMaxWidth()
                    .glassCard()
                    .padding(16.dp)
            ) {
                Text(err, color = aurora.danger, style = MaterialTheme.typography.bodyMedium)
            }
            Spacer(Modifier.height(16.dp))
        }

        // Fetching skeleton
        if (vm.fetching) {
            SkeletonCard()
        }

        // Result card
        val meta = vm.meta
        if (meta != null && !vm.fetching) {
            ResultCard(vm)
        }

        if (meta == null && !vm.fetching && vm.error == null) {
            // Hint card
            Box(
                Modifier
                    .fillMaxWidth()
                    .glassCard()
                    .padding(18.dp)
            ) {
                Column {
                    Text("How it works", style = MaterialTheme.typography.titleMedium, color = aurora.text)
                    Spacer(Modifier.height(8.dp))
                    HintLine("Paste a link from any supported platform")
                    HintLine("Pick your quality — up to 8K where available")
                    HintLine("Download stays in your Gallery: Movies/VidGrab")
                }
            }
        }

        Spacer(Modifier.height(120.dp))
    }
}

@Composable
private fun remember2(): androidx.compose.foundation.interaction.MutableInteractionSource =
    androidx.compose.runtime.remember { androidx.compose.foundation.interaction.MutableInteractionSource() }

@Composable
private fun PlatformChip(name: String, gradient: Boolean = false) {
    val aurora = LocalAurora.current
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .then(
                if (gradient) Modifier.background(
                    Brush.horizontalGradient(listOf(aurora.violet.copy(alpha = 0.8f), aurora.cyan.copy(alpha = 0.8f)))
                ) else Modifier.background(aurora.glass).border(1.dp, aurora.glassBorder, RoundedCornerShape(50))
            )
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(name, style = MaterialTheme.typography.labelSmall, color = if (gradient) Color.White else aurora.textDim)
    }
}

@Composable
private fun HintLine(text: String) {
    val aurora = LocalAurora.current
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 4.dp)
    ) {
        Box(
            Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(aurora.cyan)
        )
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = aurora.textDim)
    }
}

@Composable
private fun SkeletonCard() {
    Column {
        ShimmerBox(Modifier.fillMaxWidth().aspectRatio(16f / 9f), corner = 22)
        Spacer(Modifier.height(12.dp))
        ShimmerBox(Modifier.fillMaxWidth().height(20.dp))
        Spacer(Modifier.height(8.dp))
        ShimmerBox(Modifier.fillMaxWidth(0.6f).height(16.dp))
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            repeat(3) { ShimmerBox(Modifier.width(88.dp).height(44.dp), corner = 14) }
        }
    }
}

@Composable
private fun ResultCard(vm: HomeViewModel) {
    val aurora = LocalAurora.current
    val meta = vm.meta ?: return
    val formats = vm.formats
    val selected = formats.firstOrNull { it.id == vm.selectedId }

    Column(Modifier.fillMaxWidth()) {
        // Thumbnail
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .glassCard(highlight = true)
        ) {
            if (meta.thumbnailUrl != null) {
                AsyncImage(
                    model = meta.thumbnailUrl,
                    contentDescription = meta.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Brush.linearGradient(listOf(aurora.violet.copy(alpha = 0.4f), aurora.cyan.copy(alpha = 0.3f))))
                )
            }
            // Duration chip
            if ((meta.durationSec ?: 0) > 0) {
                Box(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .padding(10.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black.copy(alpha = 0.72f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        UrlUtils.formatDuration(meta.durationSec),
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
            // Play badge
            Box(
                Modifier
                    .align(Alignment.Center)
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(30.dp))
            }
        }

        Spacer(Modifier.height(12.dp))
        Text(
            meta.title,
            style = MaterialTheme.typography.titleLarge,
            color = aurora.text,
            maxLines = 2, overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(4.dp))
        Text(
            listOfNotNull(meta.uploader, meta.platform).joinToString("  •  "),
            style = MaterialTheme.typography.bodySmall,
            color = aurora.textDim
        )

        Spacer(Modifier.height(16.dp))

        // Quality pills — POORA ladder (Best → 8K …)
        Text("Quality", style = MaterialTheme.typography.labelLarge, color = aurora.textDim)
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(formats.filter { !it.isAudioOnly }, key = { it.id }) { f ->
                QualityPill(f, selected = f.id == vm.selectedId) { vm.select(f.id) }
            }
        }

        Spacer(Modifier.height(12.dp))

        // Audio pills
        Text("Audio only", style = MaterialTheme.typography.labelLarge, color = aurora.textDim)
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(formats.filter { it.isAudioOnly }, key = { it.id }) { f ->
                QualityPill(f, selected = f.id == vm.selectedId) { vm.select(f.id) }
            }
        }

        Spacer(Modifier.height(20.dp))

        // Download CTA
        GradientButton(
            text = when {
                vm.addedToQueue -> "Added to downloads"
                selected?.isAudioOnly == true -> "Download audio"
                else -> "Download ${selected?.label ?: ""}".trim()
            },
            icon = if (vm.addedToQueue) Icons.Filled.CheckCircle else VidIcons.Download,
            enabled = !vm.enqueuing && !vm.addedToQueue,
            loading = vm.enqueuing
        ) {
            vm.download()
        }
        AnimatedVisibility(vm.addedToQueue) {
            Row(
                Modifier.padding(top = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.CheckCircle, null, tint = aurora.success, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Downloading in background — you can switch tabs", color = aurora.success, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun QualityPill(f: FormatOption, selected: Boolean, onClick: () -> Unit) {
    val aurora = LocalAurora.current
    val interaction = remember2()
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current

    // Bouncy scale pop on select
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.06f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "pillScale"
    )

    Box(
        Modifier
            .scale(scale)
            .pressScale(interaction)
            .clip(RoundedCornerShape(14.dp))
            .then(
                if (selected) Modifier.background(aurora.gradient)
                else Modifier
                    .background(aurora.glass)
                    .border(1.dp, aurora.glassBorder, RoundedCornerShape(14.dp))
            )
            .clickable(interactionSource = interaction, indication = null, onClick = {
                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                onClick()
            })
            .padding(horizontal = 14.dp, vertical = 9.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (selected) {
                    Icon(
                        Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                }
                Text(
                    f.label,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = if (selected) Color.White else aurora.text
                )
            }
            f.detail?.let {
                Text(
                    it.substringAfter("•").trim().ifBlank { it },
                    style = MaterialTheme.typography.labelSmall,
                    color = if (selected) Color.White.copy(alpha = 0.85f) else aurora.textDim
                )
            }
        }
    }
}
