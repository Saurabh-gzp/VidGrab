package com.vidgrab.app.ui.screens

import android.content.Intent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.vidgrab.app.core.DlStatus
import com.vidgrab.app.core.DownloadRepository
import com.vidgrab.app.core.DownloadItem
import com.vidgrab.app.core.HistoryEntry
import com.vidgrab.app.ui.components.ConfirmDialog
import com.vidgrab.app.ui.components.EmptyState
import com.vidgrab.app.ui.components.ProgressRing
import com.vidgrab.app.ui.components.VidIcons
import com.vidgrab.app.ui.components.glassCard
import com.vidgrab.app.ui.theme.LocalAurora
import com.vidgrab.app.util.UrlUtils
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DownloadsScreen() {
    val aurora = LocalAurora.current
    val active by DownloadRepository.active.collectAsState()
    val history by DownloadRepository.history.collectAsState()

    if (active.isEmpty() && history.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
            Spacer(Modifier.height(18.dp))
            Text("Downloads", style = MaterialTheme.typography.displaySmall, color = aurora.text)
            Spacer(Modifier.height(40.dp))
            EmptyState(
                VidIcons.VideoLibrary,
                "Nothing here yet",
                "Grab a video from the Home tab and it will show up here."
            )
        }
        return
    }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        item {
            Spacer(Modifier.height(18.dp))
            Text("Downloads", style = MaterialTheme.typography.displaySmall, color = aurora.text)
            Spacer(Modifier.height(16.dp))
        }

        // ----- Active -----
        if (active.isNotEmpty()) {
            item {
                Text("In progress", style = MaterialTheme.typography.labelLarge, color = aurora.textDim)
                Spacer(Modifier.height(10.dp))
            }
            // CRASH FIX: section-prefixed keys — active aur history mein kabhi
            // same raw id ho (download-complete overlap window) to bhi
            // LazyColumn duplicate-key crash impossible hai
            items(active, key = { "a_${it.id}" }) { item ->
                ActiveCard(item)
                Spacer(Modifier.height(10.dp))
            }
        }

        // ----- History -----
        if (history.isNotEmpty()) {
            item {
                Spacer(Modifier.height(14.dp))
                Text("Saved on device", style = MaterialTheme.typography.labelLarge, color = aurora.textDim)
                Spacer(Modifier.height(10.dp))
            }
            items(history, key = { "h_${it.id}" }) { entry ->
                HistoryCard(entry)
                Spacer(Modifier.height(10.dp))
            }
        }

        item { Spacer(Modifier.height(120.dp)) }
    }
}

/** Aurora progress bar — animated fill + shimmer sweep (premium feel) */
@Composable
private fun AuroraProgressBar(progress: Float, indeterminate: Boolean) {
    val aurora = LocalAurora.current
    val animated by animateFloatAsState(
        targetValue = (progress / 100f).coerceIn(0f, 1f),
        animationSpec = tween(420),
        label = "dlProgress"
    )
    val shimmer = rememberInfiniteTransition(label = "pbar")
    val sweep by shimmer.animateFloat(
        initialValue = -0.4f, targetValue = 1.4f,
        animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing), RepeatMode.Restart),
        label = "sweep"
    )
    Box(
        Modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(50))
            .background(aurora.glassBorder)
    ) {
        Box(
            Modifier
                .fillMaxWidth(if (indeterminate) 0.35f else animated)
                .fillMaxHeight()
                .clip(RoundedCornerShape(50))
                .background(
                    if (indeterminate) Brush.linearGradient(
                        listOf(aurora.violet.copy(alpha = 0.45f), aurora.cyan.copy(alpha = 0.35f))
                    ) else aurora.gradient
                )
                .drawBehind {
                    if (!indeterminate) {
                        drawRect(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color.White.copy(alpha = 0.5f),
                                    Color.Transparent
                                ),
                                start = Offset(sweep * size.width, 0f),
                                end = Offset(sweep * size.width + 120f, size.height)
                            )
                        )
                    }
                }
        )
    }
}

@Composable
private fun ActiveCard(item: DownloadItem) {
    val aurora = LocalAurora.current
    Box(Modifier.fillMaxWidth().glassCard(highlight = item.status == DlStatus.DOWNLOADING)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            // Thumbnail / ring
            Box(Modifier.size(64.dp, 46.dp)) {
                if (item.thumbnailUrl != null) {
                    AsyncImage(
                        model = item.thumbnailUrl,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp))
                    )
                } else {
                    Box(
                        Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp))
                            .background(Brush.linearGradient(listOf(aurora.violet.copy(alpha = .5f), aurora.cyan.copy(alpha = .35f))))
                    )
                }
                if (item.status == DlStatus.DOWNLOADING || item.status == DlStatus.MERGING || item.status == DlStatus.FETCHING || item.status == DlStatus.QUEUED) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(30.dp)) {
                            when (item.status) {
                                // v2.2.1: MERGING par spinning ring — static full ring
                                // frozen lagta tha (user: "finalizing stuck")
                                DlStatus.MERGING -> ProgressRing(progress = 0f, sizeDp = 30, stroke = 4, indeterminate = true)
                                DlStatus.FETCHING -> ProgressRing(progress = 0f, sizeDp = 30, stroke = 4, indeterminate = true)
                                else -> ProgressRing(progress = item.progress, sizeDp = 30, stroke = 4)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    item.title, style = MaterialTheme.typography.titleMedium,
                    color = aurora.text, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(3.dp))
                val statusText = when (item.status) {
                    // USER REQUEST: download start hone se pehle "Processing…" dikhe
                    DlStatus.QUEUED -> "Processing… • ${item.formatLabel}"
                    DlStatus.FETCHING -> "Processing…"
                    DlStatus.DOWNLOADING -> {
                        val sp = if (item.speedBps > 0) " • ${UrlUtils.formatSpeed(item.speedBps)}" else ""
                        val eta = if (item.etaSec >= 0) " • ${UrlUtils.formatEta(item.etaSec)}" else ""
                        "Downloading ${item.progress.toInt()}%$sp$eta"
                    }
                    DlStatus.MERGING -> "Finalizing — merging video & audio…"
                    DlStatus.DONE -> "Saved"
                    DlStatus.FAILED -> item.error ?: "Failed"
                    DlStatus.CANCELLED -> "Cancelled"
                }
                Text(
                    statusText,
                    style = MaterialTheme.typography.bodySmall,
                    color = when (item.status) {
                        DlStatus.FAILED -> aurora.danger
                        DlStatus.DONE -> aurora.success
                        else -> aurora.textDim
                    },
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                // v2.2.1: MERGING par bhi indeterminate bar chale — merge/faststart/save
                // ke dauran UI bilkul static reh kar FROZEN lagta tha
                if (item.status == DlStatus.DOWNLOADING || item.status == DlStatus.QUEUED || item.status == DlStatus.FETCHING || item.status == DlStatus.MERGING) {
                    Spacer(Modifier.height(8.dp))
                    AuroraProgressBar(
                        progress = item.progress,
                        indeterminate = item.status != DlStatus.DOWNLOADING
                    )
                }
            }
            Spacer(Modifier.width(8.dp))
            // Cancel / dismiss
            IconButton(onClick = {
                when (item.status) {
                    DlStatus.QUEUED, DlStatus.FETCHING, DlStatus.DOWNLOADING, DlStatus.MERGING ->
                        DownloadRepository.cancel(item.id)
                    else -> DownloadRepository.dismiss(item.id)
                }
            }) {
                Icon(Icons.Filled.Clear, contentDescription = "Remove", tint = aurora.textDim)
            }
        }
    }
}

@Composable
private fun HistoryCard(entry: HistoryEntry) {
    val aurora = LocalAurora.current
    val ctx = LocalContext.current
    var showDelete by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxWidth().glassCard()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(72.dp, 48.dp).clip(RoundedCornerShape(12.dp))
                    .background(aurora.glassBorder)
            ) {
                if (entry.thumbnailUrl != null) {
                    AsyncImage(
                        model = entry.thumbnailUrl,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.CheckCircle, null, tint = aurora.success)
                    }
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    entry.title, style = MaterialTheme.typography.titleMedium,
                    color = aurora.text, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(3.dp))
                val date = SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()).format(Date(entry.completedAtMs))
                Text(
                    "${UrlUtils.formatBytes(entry.sizeBytes)} • ${entry.formatLabel.ifBlank { entry.mime }} • $date",
                    style = MaterialTheme.typography.bodySmall, color = aurora.textDim,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.width(4.dp))
            Box {
                IconButton(onClick = { menuOpen = true }) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "More", tint = aurora.textDim)
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("Open") },
                        onClick = {
                            menuOpen = false
                            openSavedFile(ctx, entry)
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Share") },
                        leadingIcon = { Icon(Icons.Filled.Share, null) },
                        onClick = {
                            menuOpen = false
                            shareSavedFile(ctx, entry)
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete", color = aurora.danger) },
                        leadingIcon = { Icon(Icons.Filled.Delete, null, tint = aurora.danger) },
                        onClick = {
                            menuOpen = false
                            showDelete = true
                        }
                    )
                }
            }
        }
    }

    if (showDelete) {
        ConfirmDialog(
            title = "Delete this download?",
            body = "\"${entry.title.take(60)}\" will be removed from your device storage. This can't be undone.",
            confirmLabel = "Delete",
            onConfirm = {
                showDelete = false
                DownloadRepository.deleteHistory(entry)
            },
            onDismiss = { showDelete = false }
        )
    }
}

private fun openSavedFile(ctx: android.content.Context, entry: HistoryEntry) {
    try {
        val uri = androidx.core.content.FileProvider.getUriForFile(
            ctx, ctx.packageName + ".provider", File("/storage/emulated/0/" + entry.filePath)
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, entry.mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(intent)
    } catch (_: Exception) {
    }
}

private fun shareSavedFile(ctx: android.content.Context, entry: HistoryEntry) {
    try {
        val uri = androidx.core.content.FileProvider.getUriForFile(
            ctx, ctx.packageName + ".provider", File("/storage/emulated/0/" + entry.filePath)
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = entry.mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(intent, "Share via").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    } catch (_: Exception) {
    }
}
