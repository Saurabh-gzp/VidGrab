package com.vidgrab.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vidgrab.app.BuildConfig
import com.vidgrab.app.core.Prefs
import com.vidgrab.app.core.UpdateManager
import com.vidgrab.app.ui.components.VidIcons
import com.vidgrab.app.ui.components.glassCard
import com.vidgrab.app.ui.theme.LocalAurora

@Composable
fun SettingsScreen(themeFlow: kotlinx.coroutines.flow.Flow<Prefs.ThemeMode>, onTheme: (Prefs.ThemeMode) -> Unit) {
    val aurora = LocalAurora.current
    val theme by themeFlow.collectAsState(initial = Prefs.ThemeMode.System)
    val appCtx = androidx.compose.ui.platform.LocalContext.current.applicationContext

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(18.dp))
        Text("Settings", style = MaterialTheme.typography.displaySmall, color = aurora.text)
        Spacer(Modifier.height(20.dp))

        // ---- Appearance ----
        SectionCard(icon = VidIcons.Moon, title = "Appearance") {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                listOf(Prefs.ThemeMode.System, Prefs.ThemeMode.Dark, Prefs.ThemeMode.Light)
                    .forEachIndexed { i, mode ->
                        SegmentedButton(
                            selected = theme == mode,
                            onClick = { onTheme(mode) },
                            shape = SegmentedButtonDefaults.itemShape(index = i, count = 3),
                            colors = androidx.compose.material3.SegmentedButtonDefaults.colors(
                                activeContainerColor = aurora.violet.copy(alpha = 0.85f),
                                activeContentColor = Color.White,
                                inactiveContainerColor = aurora.glass,
                                inactiveContentColor = aurora.textDim,
                                inactiveBorderColor = aurora.glassBorder
                            )
                        ) {
                            Text(mode.label)
                        }
                    }
            }
        }

        Spacer(Modifier.height(14.dp))

        // ---- Updates ----
        SectionCard(icon = VidIcons.Update, title = "Updates") {
            Text(
                "The app keeps itself up to date automatically — you'll see a quick update screen only when something actually needs updating.",
                style = MaterialTheme.typography.bodyMedium, color = aurora.textDim
            )
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .glassCard()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(VidIcons.Shield, null, tint = aurora.violet, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(10.dp))
                Text(
                    "Check for update now",
                    style = MaterialTheme.typography.labelLarge,
                    color = aurora.text,
                    modifier = Modifier.weight(1f)
                )
                androidx.compose.material3.TextButton(onClick = { UpdateManager.manualCheck(appCtx) }) {
                    Text("Run", color = aurora.cyan)
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        // ---- Privacy ----
        SectionCard(icon = VidIcons.Shield, title = "Privacy & Security") {
            BulletLine("100% on-device processing — links never touch our servers")
            BulletLine("No account, no tracking, no ads")
            BulletLine("Downloads save straight to your Gallery")
            BulletLine("App signature locked — install only from trusted sources")
        }

        Spacer(Modifier.height(14.dp))

        // ---- About ----
        SectionCard(icon = Icons.Filled.CheckCircle, title = "About") {
            InfoRow("App", "VidGrab")
            // v2.2.3 FIX: hardcoded "2.1.0" tha — ab BuildConfig se REAL version,
            // release version se kabhi mismatch nahi hoga
            InfoRow("Version", "v" + BuildConfig.VERSION_NAME)
            InfoRow("Made with", "Care, in India")
        }

        Spacer(Modifier.height(120.dp))
    }
}

@Composable
private fun SectionCard(icon: ImageVector, title: String, content: @Composable () -> Unit) {
    val aurora = LocalAurora.current
    Column(
        Modifier
            .fillMaxWidth()
            .glassCard()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(34.dp)
                    .glassCard(highlight = true),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = aurora.violet, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(10.dp))
            Text(title, style = MaterialTheme.typography.titleLarge, color = aurora.text)
        }
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
private fun BulletLine(text: String) {
    val aurora = LocalAurora.current
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 5.dp)
    ) {
        Box(
            Modifier
                .size(6.dp)
                .clip(RoundedCornerShape(50))
                .background(aurora.cyan)
        )
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = aurora.textDim)
    }
}

@Composable
private fun InfoRow(k: String, v: String) {
    val aurora = LocalAurora.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Text(k, style = MaterialTheme.typography.bodyMedium, color = aurora.textDim)
        Spacer(Modifier.weight(1f))
        Text(v, style = MaterialTheme.typography.bodyMedium, color = aurora.text, fontWeight = FontWeight.SemiBold)
    }
}
