package com.vidgrab.app.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vidgrab.app.core.Engine
import com.vidgrab.app.core.FormatOption
import com.vidgrab.app.core.VideoMeta
import com.vidgrab.app.core.DownloadRepository
import com.vidgrab.app.util.Fetcher
import com.vidgrab.app.util.UrlUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Home ka poora state yahan — tab switch par bhi paste/fetch sab intact rehta hai.
 */
class HomeViewModel(app: Application) : AndroidViewModel(app) {

    var url by mutableStateOf("")
        private set
    var fetching by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var meta by mutableStateOf<VideoMeta?>(null)
        private set
    var formats by mutableStateOf<List<FormatOption>>(emptyList())
        private set
    var selectedId by mutableStateOf<String?>(null)
        private set
    var enqueuing by mutableStateOf(false)
        private set
    var addedToQueue by mutableStateOf(false)
        private set

    fun onUrlChange(u: String) {
        url = u
        error = null
    }

    fun clearAll() {
        url = ""; error = null; meta = null; formats = emptyList()
        selectedId = null; fetching = false; enqueuing = false; addedToQueue = false
    }

    fun select(id: String) {
        selectedId = id
        addedToQueue = false
    }

    fun fetch(rawUrl: String? = null) {
        val target = (rawUrl ?: url).trim()
        if (target.isBlank() || fetching) return
        if (rawUrl != null) url = rawUrl
        viewModelScope.launch {
            fetching = true
            error = null
            meta = null
            formats = emptyList()
            addedToQueue = false
            try {
                withContext(Dispatchers.IO) { Engine.await() }
                val res = Fetcher.fetchInfo(getApplication(), target)
                meta = res.meta
                formats = res.formats
                selectedId = res.formats.firstOrNull { it.id == "best" }?.id
                    ?: res.formats.firstOrNull()?.id
                if (formats.isEmpty()) error = "No downloadable formats found"
            } catch (e: Exception) {
                val raw = e.message ?: "Could not fetch this link"
                error = friendlyError(raw)
            } finally {
                fetching = false
            }
        }
    }

    fun download() {
        val m = meta ?: return
        val f = formats.firstOrNull { it.id == selectedId } ?: formats.firstOrNull() ?: return
        if (enqueuing) return
        viewModelScope.launch {
            enqueuing = true
            try {
                DownloadRepository.enqueue(url = m.webpageUrl, meta = m, format = f)
                addedToQueue = true
            } finally {
                enqueuing = false
            }
        }
    }

    private fun friendlyError(raw: String): String = UrlUtils.friendlyEngineError(raw)
}
