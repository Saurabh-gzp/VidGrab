package com.vidgrab.app.core

import android.content.Context
import android.content.Intent
import com.vidgrab.app.service.UpdateService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

/**
 * App launch par silent engine-update check:
 *  - agar installed component version < latest release -> foreground service + overlay
 *  - warna kuch nahi dikhta (koi prompt nahi)
 */
object UpdateManager {

    private val _state = MutableStateFlow<UpdateState>(UpdateState.Idle)
    val state: StateFlow<UpdateState> = _state

    private val busy = AtomicBoolean(false)

    fun isUpdating(): Boolean = _state.value is UpdateState.Updating

    fun setProgress(progress: Float, etaSec: Long, line: String) {
        _state.value = UpdateState.Updating(progress, etaSec, line)
    }

    fun markDone() { _state.value = UpdateState.Done }
    fun markFailed() { if (isUpdating()) _state.value = UpdateState.Failed }
    fun resetToIdle() { _state.value = UpdateState.Idle }

    /** App cold start par call hota hai. Sirf real update mile to service start karo. */
    suspend fun checkOnLaunch(context: Context) {
        if (!busy.compareAndSet(false, true)) return
        try {
            _state.value = UpdateState.Checking
            val installed = withContext(Dispatchers.IO) {
                try { com.yausername.youtubedl_android.YoutubeDL.getInstance().version(context) } catch (_: Exception) { null }
            }
            val latest = withContext(Dispatchers.IO) { fetchLatestTag() }
            if (installed == null || latest == null) {
                _state.value = UpdateState.Idle
                return
            }
            if (isNewer(latest, installed)) {
                // Real update hai -> foreground service (app close ho to bhi chalta rahega)
                _state.value = UpdateState.Idle
                val i = Intent(context, UpdateService::class.java)
                try {
                    context.startForegroundService(i)
                } catch (_: Exception) {
                    // Service start na ho paye — chupchaap skip, agli baar phir try hoga
                    _state.value = UpdateState.Failed
                    delay(1500)
                    _state.value = UpdateState.Idle
                }
            } else {
                _state.value = UpdateState.Idle
            }
        } catch (_: Exception) {
            _state.value = UpdateState.Idle
        } finally {
            busy.set(false)
        }
    }

    /** Manual trigger (Settings se) — hamesha service route */
    fun manualCheck(context: Context) {
        val appCtx = context.applicationContext
        Thread {
            try {
                _state.value = UpdateState.Checking
                val installed = try {
                    com.yausername.youtubedl_android.YoutubeDL.getInstance().version(appCtx)
                } catch (_: Exception) { null }
                val latest = fetchLatestTag()
                if (installed == null || latest == null) { _state.value = UpdateState.Idle; return@Thread }
                if (isNewer(latest, installed)) {
                    _state.value = UpdateState.Idle
                    appCtx.startForegroundService(Intent(appCtx, UpdateService::class.java))
                } else {
                    // Already latest — halka sa feedback
                    _state.value = UpdateState.Done
                    Thread.sleep(1200)
                    _state.value = UpdateState.Idle
                }
            } catch (_: Exception) {
                _state.value = UpdateState.Idle
            }
        }.start()
    }

    private fun fetchLatestTag(): String? {
        return try {
            val conn = URL("https://api.github.com/repos/yt-dlp/yt-dlp/releases/latest").openConnection() as HttpURLConnection
            conn.connectTimeout = 6000
            conn.readTimeout = 6000
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            conn.setRequestProperty("User-Agent", "VidGrab")
            if (conn.responseCode != 200) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            JSONObject(body).optString("tag_name", "").takeIf { it.isNotBlank() }
        } catch (_: Exception) { null }
    }

    /** Latest release ka tag + yt-dlp asset (download progress ke liye) */
    fun fetchLatestRelease(): Triple<String, String, Long>? {
        return try {
            val conn = URL("https://api.github.com/repos/yt-dlp/yt-dlp/releases/latest").openConnection() as HttpURLConnection
            conn.connectTimeout = 6000
            conn.readTimeout = 6000
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            conn.setRequestProperty("User-Agent", "VidGrab")
            if (conn.responseCode != 200) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)
            val tag = json.optString("tag_name", "").takeIf { it.isNotBlank() } ?: return null
            var assetUrl: String? = null
            var assetSize = 0L
            val assets = json.optJSONArray("assets")
            if (assets != null) {
                for (i in 0 until assets.length()) {
                    val a = assets.optJSONObject(i) ?: continue
                    if (a.optString("name") == "yt-dlp") {
                        assetUrl = a.optString("browser_download_url")
                        assetSize = a.optLong("size", 0L)
                        break
                    }
                }
            }
            val url = assetUrl ?: return null
            Triple(tag, url, assetSize)
        } catch (_: Exception) { null }
    }

    /** Streaming download with REAL progress (bytes + ETA) */
    fun downloadAsset(
        url: String,
        dest: java.io.File,
        onProgress: (bytesRead: Long, totalBytes: Long) -> Unit
    ): Boolean {
        return try {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 10000
            conn.readTimeout = 20000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", "VidGrab")
            if (conn.responseCode !in 200..299) return false
            val total = conn.contentLengthLong.takeIf { it > 0 } ?: -1L
            dest.parentFile?.mkdirs()
            dest.outputStream().use { out ->
                conn.inputStream.use { input ->
                    val buf = ByteArray(64 * 1024)
                    var read = 0L
                    var n = input.read(buf)
                    while (n >= 0) {
                        out.write(buf, 0, n)
                        read += n
                        onProgress(read, total)
                        n = input.read(buf)
                    }
                }
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    /** "2026.08.19" vs "2025.06.09" style compare */
    fun isNewer(latest: String, installed: String): Boolean {
        val l = parseVersion(latest) ?: return false
        val i = parseVersion(installed) ?: return true
        if (l.first != i.first) return l.first > i.first
        if (l.second != i.second) return l.second > i.second
        return l.third > i.third
    }

    private fun parseVersion(v: String): Triple<Long, Long, Long>? {
        val clean = v.trim().removePrefix("v").split("-", "+")[0]
        val parts = clean.split(".")
        if (parts.size < 2) return null
        return try {
            val a = parts.getOrNull(0)?.filter { it.isDigit() }?.toLong() ?: 0L
            val b = parts.getOrNull(1)?.filter { it.isDigit() }?.toLong() ?: 0L
            val c = parts.getOrNull(2)?.filter { it.isDigit() }?.toLong() ?: 0L
            Triple(a, b, c)
        } catch (_: Exception) { null }
    }
}
