package com.vidgrab.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vidgrab.app.core.Prefs

// ---------- Aurora palette ----------
val Midnight = Color(0xFF0A0E1A)
val SurfaceDark = Color(0xFF121828)
val SurfaceDarkHigh = Color(0xFF1A2136)
val InkWhite = Color(0xFFF2F5FA)
val InkDim = Color(0xFF97A1BA)
val InkFaint = Color(0xFF5A6478)
val AuroraViolet = Color(0xFF7C5CFF)
val AuroraCyan = Color(0xFF22D3EE)
val AuroraMagenta = Color(0xFFFF3D8D)
val Success = Color(0xFF34D399)
val Danger = Color(0xFFFF5C6C)
val GlassWhite = Color(0x14FFFFFF)
val GlassBorder = Color(0x24FFFFFF)

val PaperLight = Color(0xFFF5F7FC)
val SurfaceLight = Color(0xFFFFFFFF)
val InkDark = Color(0xFF101426)
val InkDimLight = Color(0xFF5A6478)
val GlassDark = Color(0x0D1A2236)
val GlassBorderLight = Color(0x1A101426)

@Immutable
data class AuroraColors(
    val bg: Color,
    val surface: Color,
    val surfaceHigh: Color,
    val text: Color,
    val textDim: Color,
    val textFaint: Color,
    val glass: Color,
    val glassBorder: Color,
    val violet: Color,
    val cyan: Color,
    val magenta: Color,
    val success: Color,
    val danger: Color,
    val isDark: Boolean
) {
    val primary: Color get() = violet
    val gradient: Brush
        get() = Brush.linearGradient(listOf(violet, cyan), tileMode = TileMode.Mirror)
    val gradientWarm: Brush
        get() = Brush.linearGradient(listOf(magenta, violet))
    val gradientSoft: Brush
        get() = Brush.linearGradient(listOf(violet.copy(alpha = 0.55f), cyan.copy(alpha = 0.35f)))
}

val LocalAurora = staticCompositionLocalOf {
    AuroraColors(
        Midnight, SurfaceDark, SurfaceDarkHigh, InkWhite, InkDim, InkFaint,
        GlassWhite, GlassBorder, AuroraViolet, AuroraCyan, AuroraMagenta, Success, Danger, true
    )
}

private val DarkScheme = darkColorScheme(
    primary = AuroraViolet,
    secondary = AuroraCyan,
    tertiary = AuroraMagenta,
    background = Midnight,
    surface = SurfaceDark,
    surfaceVariant = SurfaceDarkHigh,
    onPrimary = Color.White,
    onBackground = InkWhite,
    onSurface = InkWhite,
    onSurfaceVariant = InkDim,
    outline = GlassBorder,
    error = Danger
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF6246EA),
    secondary = Color(0xFF0891B2),
    tertiary = Color(0xFFE11D74),
    background = PaperLight,
    surface = SurfaceLight,
    surfaceVariant = Color(0xFFEDF0F8),
    onPrimary = Color.White,
    onBackground = InkDark,
    onSurface = InkDark,
    onSurfaceVariant = InkDimLight,
    outline = GlassBorderLight,
    error = Color(0xFFE5484D)
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

private val AppTypography = Typography(
    displaySmall = TextStyle(
        fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.ExtraBold,
        fontSize = 32.sp, letterSpacing = (-0.5).sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold,
        fontSize = 24.sp, letterSpacing = (-0.3).sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 19.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 16.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 15.5.sp,
        lineHeight = 23.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 12.5.sp
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 14.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 11.sp,
        letterSpacing = 0.3.sp
    )
)

@Composable
fun VidGrabTheme(mode: Prefs.ThemeMode = Prefs.ThemeMode.System, content: @Composable () -> Unit) {
    val dark = when (mode) {
        Prefs.ThemeMode.Dark -> true
        Prefs.ThemeMode.Light -> false
        Prefs.ThemeMode.System -> isSystemInDarkTheme()
    }
    val aurora = if (dark) {
        AuroraColors(
            Midnight, SurfaceDark, SurfaceDarkHigh, InkWhite, InkDim, InkFaint,
            GlassWhite, GlassBorder, AuroraViolet, AuroraCyan, AuroraMagenta, Success, Danger, true
        )
    } else {
        AuroraColors(
            PaperLight, SurfaceLight, Color(0xFFF0F2F9), InkDark, InkDimLight, Color(0xFF98A0B3),
            GlassDark, GlassBorderLight, Color(0xFF6246EA), Color(0xFF0891B2), Color(0xFFE11D74),
            Color(0xFF10B981), Color(0xFFE5484D), false
        )
    }
    CompositionLocalProvider(LocalAurora provides aurora) {
        MaterialTheme(
            colorScheme = if (dark) DarkScheme else LightScheme,
            typography = AppTypography,
            shapes = AppShapes,
            content = content
        )
    }
}
