package com.vidgrab.app.util

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import java.io.File

/**
 * v2.2 Storage saver:
 *  - All Files Access mila ho to TOP-LEVEL "VidGrab" folder:
 *      VidGrab/Video/...  (videos)
 *      VidGrab/Audio/...  (audio)
 *    + MediaScanner se gallery index — user ko exactly yahi chahiye.
 *  - Permission na ho to MediaStore fallback:
 *      Movies/VidGrab/Video/...  aur  Music/VidGrab/Audio/...
 *    (Android 10 scoped storage mein top-level custom folder allowed nahi hai)
 */
object MediaSaver {

    const val ROOT_DIR = "VidGrab"

    /** Android 11+ All Files Access — Android 10 (API 29) par hamesha false */
    fun hasAllFilesAccess(ctx: Context): Boolean =
        Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()

    /** Settings screen jahan se user "All files access" toggle on karta hai */
    fun allFilesAccessIntent(ctx: Context): Intent = try {
        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
    } catch (_: Exception) {
        Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
    }

    /**
     * Save karo. Return: (MediaStore-Uri ya null, public relative path)
     * Relative path /storage/emulated/0/ ke relative hota hai —
     * e.g. "VidGrab/Video/My Video (1080p).mp4"
     */
    fun save(ctx: Context, src: File, isAudio: Boolean): Pair<Uri?, String>? {
        if (hasAllFilesAccess(ctx)) {
            saveDirect(ctx, src, isAudio)?.let { return it }
        }
        return saveMediaStore(ctx, src, isAudio)
    }

    /** Direct write: /storage/emulated/0/VidGrab/{Video|Audio}/ */
    private fun saveDirect(ctx: Context, src: File, isAudio: Boolean): Pair<Uri?, String>? {
        return try {
            val sub = if (isAudio) "Audio" else "Video"
            val dir = File(Environment.getExternalStorageDirectory(), "$ROOT_DIR/$sub")
            if (!dir.exists() && !dir.mkdirs()) return null
            var dest = File(dir, src.name)
            if (dest.exists()) {
                // Collision — "name (2).ext" suffix
                val base = src.name.substringBeforeLast('.')
                val ext = src.name.substringAfterLast('.', "mp4")
                var n = 2
                dest = File(dir, "$base ($n).$ext")
                while (dest.exists()) { n++; dest = File(dir, "$base ($n).$ext") }
            }
            src.copyTo(dest, overwrite = false)
            // Gallery/file-manager index
            MediaScannerConnection.scanFile(ctx, arrayOf(dest.absolutePath), arrayOf(mimeOf(dest.name, isAudio)), null)
            null to "$ROOT_DIR/$sub/${dest.name}"
        } catch (_: Exception) {
            null // direct write fail — MediaStore fallback
        }
    }

    /** Scoped-storage fallback: Movies/Music ke andar VidGrab/{Video|Audio} */
    private fun saveMediaStore(ctx: Context, src: File, isAudio: Boolean): Pair<Uri, String>? {
        return try {
            val collection = if (isAudio)
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            else
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)

            val mime = mimeOf(src.name, isAudio)
            val folder = if (isAudio) "Music/$ROOT_DIR/Audio/" else "Movies/$ROOT_DIR/Video/"
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, src.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, folder)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val resolver = ctx.contentResolver
            val uri = resolver.insert(collection, values) ?: return null
            resolver.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            uri to (folder + src.name)
        } catch (_: Exception) {
            null
        }
    }

    /** MediaStore entry + file dono delete (dono save modes handle) */
    fun deleteByPath(ctx: Context, path: String): Boolean {
        var ok = false
        try {
            val name = path.substringAfterLast('/')
            val relPath = path.substringBeforeLast('/')
            val isAudio = path.startsWith("Music/") || path.contains("/Audio/")
            val collection = if (isAudio)
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            else
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)

            val resolver = ctx.contentResolver
            // RELATIVE_PATH exact match + DISPLAY_NAME match
            resolver.query(
                collection,
                arrayOf(MediaStore.MediaColumns._ID),
                "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND ${MediaStore.MediaColumns.DISPLAY_NAME}=?",
                arrayOf("$relPath/", name),
                null
            )?.use { c ->
                while (c.moveToNext()) {
                    val uri = ContentUris.withAppendedId(collection, c.getLong(0))
                    val rows = resolver.delete(uri, null, null)
                    ok = ok || rows > 0
                }
            }
        } catch (_: Exception) { }

        // Fallback: direct file (All Files Access wale saves yahi se delete hote hain)
        try {
            val f = File("/storage/emulated/0/$path")
            if (f.exists()) ok = f.delete() || ok
        } catch (_: Exception) { }
        return ok
    }

    fun mimeOf(name: String, isAudio: Boolean): String {
        val ext = name.substringAfterLast('.', "mp4").lowercase()
        return when {
            isAudio -> when (ext) {
                "m4a" -> "audio/mp4"
                "mp3" -> "audio/mpeg"
                "opus" -> "audio/opus"
                "ogg" -> "audio/ogg"
                "wav" -> "audio/wav"
                else -> "audio/mp4"
            }
            else -> when (ext) {
                "mp4" -> "video/mp4"
                "webm" -> "video/webm"
                "mkv" -> "video/x-matroska"
                "3gp" -> "video/3gpp"
                else -> "video/mp4"
            }
        }
    }
}
